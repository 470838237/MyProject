package com.schx.ma.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;

import android.text.TextWatcher;
import android.util.Log;

import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.Base64;
import com.schx.ma.GlobalData;
import com.schx.ma.Job;
import com.schx.ma.R;
import com.schx.ma.util.MySQLiteOpenHelper;
import com.schx.ma.util.SearchListAdapter;
import com.schx.ma.util.SearchRecordAdapter;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class SearchActivity extends Activity {
    public GlobalData app = MainActivity.appdata;
    EditText mSearchET;
    ImageView mCategoryIV;
    MyPopWindow mMyPopWindow;
    LinearLayout mCategoryContainer;
    TextView mCompany, mAddress, mMistake, mDate, mCategoryTV, mNullText, displayDate;
    ImageView mSelectIcon, mDeleteText, mSearch, mCalendarIcon;
    View view;
    LayoutInflater inflater;
    ArrayList<String> dataList;
    SearchListAdapter adapter;
    MyPopWindow searchWarming;
    RelativeLayout listViewContainer;
    ImageButton calendarLeft, calendarRight;
    LinearLayout mSearchBar, noSearch, parent;
    public ArrayList<Integer> idList;
    ArrayList<Job> jobs;
    ListView listView, recordListView;
    com.schx.ma.userdefineview.CalendarView mCalendarView;
    InputMethodManager imm;
    RelativeLayout calendarContainer;
    SharedPreferences preferences;
    public SharedPreferences.Editor editor;
    MyPopWindow calendarWindow;
    boolean controlInput;
    ArrayList<String> searchRecordList;
    RelativeLayout clear;
    SearchRecordAdapter searchRecordAdapter;
    final static int WAIT_DEAL = 1;
    final static int VIEW_JOB = 2;
    final static int CREATE_JOB = 3;
    public static int currentState = -1;
    public String key;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_search);
        Intent intent = getIntent();
        currentState = intent.getIntExtra("state", -1);
        init();
        parent = (LinearLayout) findViewById(R.id.parent);

        parent.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft, int oldTop, int oldRight, int oldBottom) {
                RelativeLayout.LayoutParams vp = new RelativeLayout.LayoutParams(-1, -2);


                if (bottom - oldBottom >0) {
                    vp.bottomMargin = 0;
                } else {
                    vp.bottomMargin = 1000;
                }
                listView.setLayoutParams(vp);

            }
        });
    }

    public void init() {

        imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        idList = new ArrayList<Integer>();
        searchRecordList = new ArrayList<String>();
        dataList = new ArrayList<String>();
        jobs = new ArrayList<Job>();
        inflater = getLayoutInflater();
        listViewContainer = (RelativeLayout) inflater.inflate(R.layout.search_warming_list, null);
        listView = (ListView) listViewContainer.findViewById(R.id.warn_listView);
        adapter = new SearchListAdapter(dataList, this);
        listView.setAdapter(adapter);
        calendarLeft = (ImageButton) findViewById(R.id.calendarLeft);
        calendarContainer = (RelativeLayout) inflater.inflate(R.layout.search_calendar_layout, null);
        displayDate = (TextView) calendarContainer.findViewById(R.id.displayDate);
        calendarRight = (ImageButton) findViewById(R.id.calendarRight);
        noSearch = (LinearLayout) findViewById(R.id.no_search);
        clear = (RelativeLayout) findViewById(R.id.clear);
        recordListView = (ListView) findViewById(R.id.recordListView);
        mCalendarIcon = (ImageView) findViewById(R.id.calendarIcon);
        mSearchET = (EditText) findViewById(R.id.search_et);
        mCategoryIV = (ImageView) findViewById(R.id.categoryIV);
        mCategoryContainer = (LinearLayout) findViewById(R.id.categoryContainer);
        mSearchBar = (LinearLayout) findViewById(R.id.searchBar);
        view = inflater.inflate(R.layout.search_popwindow, null);
        mCompany = (TextView) view.findViewById(R.id.company);
        mAddress = (TextView) view.findViewById(R.id.address);
        mMistake = (TextView) view.findViewById(R.id.mistake);
        mDate = (TextView) view.findViewById(R.id.date);
        mCategoryTV = (TextView) findViewById(R.id.categoryTV);
        mSelectIcon = (ImageView) findViewById(R.id.selectIcon);
        mDeleteText = (ImageView) findViewById(R.id.delete_text);
        mNullText = (TextView) view.findViewById(R.id.null_text);
        mSearch = (ImageView) findViewById(R.id.selectIcon);

        showInput();
        key = app.getLoginId()+"searchRecord" + currentState;
        preferences = getSharedPreferences(key, Context.MODE_PRIVATE);
        editor = preferences.edit();
        if (preferences.getString(key, null) != null) {
            searchRecordList = (ArrayList<String>) getSearchRecord(preferences.getString(key, null));
        }

        if (searchRecordList.size() > 0) {
            searchRecordAdapter = new SearchRecordAdapter(searchRecordList, this);
            recordListView.setAdapter(searchRecordAdapter);
            noSearch.setVisibility(View.GONE);
            recordListView.setVisibility(View.VISIBLE);
            clear.setVisibility(View.VISIBLE);
        } else {
            noSearch.setVisibility(View.VISIBLE);
            recordListView.setVisibility(View.GONE);
            clear.setVisibility(View.GONE);
        }

        mSearchET.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0 && mDeleteText.getVisibility() == View.INVISIBLE) {
                    mDeleteText.setVisibility(View.VISIBLE);

                } else if (s.length() == 0 && mDeleteText.getVisibility() == View.VISIBLE) {
                    mDeleteText.setVisibility(View.INVISIBLE);

                }
                searchWarming(s.toString());

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        mDeleteText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSearchET.setText("");
            }
        });
        mCategoryContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mMyPopWindow != null) {
                    mMyPopWindow.dismiss();
                }
                turnWindowDark();
                mMyPopWindow = getPopWindow(view, mCategoryContainer, 3);

                mMyPopWindow.setOnDismissListener(onDismissListener);

            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                turnWindowLight();
                searchWarming.setFocusable(true);
                searchWarming.dismiss();
                String content = ((TextView) view.getTag()).getText().toString();
                mSearchET.setText(content);
                String select = null;
                Integer state = (Integer) parent.getTag();
                Log.e("---state", "--" + state);
                if (state != null) {
                    if (state == 1) {
                        select = "select jobid from jobinfo where company=? and state=? and isExist=1 and userid=?";
                    } else if (state == 2) {
                        select = "select jobid from jobinfo where address=? and state=? and isExist=1 and userid=?";
                    } else if (state == 3) {
                        select = "select jobid from jobinfo where mistake=? and state=? and isExist=1 and userid=?";
                    }
                } else {
                    select = "select jobid from jobinfo where content=? and state=? and isExist=1 and userid=?";
                }
//                if (!searchRecordList.contains(content)) {
//                    searchRecordList.add(content);
//                    editor.putString("searchRecord", saveSearchRecord(searchRecordList)).commit();
//                }
                String[] values = new String[]{content, currentState + "",app.getLoginId()};
                GlobalData.getDBhelper(SearchActivity.this).selectJob(select, values, idList);
                if (searchWarming != null) {
                    searchWarming.dismiss();
                }
                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putSerializable("idList", idList);
                intent.putExtras(bundle);
                //设置回调的方法
                setResult(1, intent);
                finish();
            }
        });

    }

    public void turnLeft(View v) {
        mCalendarView.clickLeftMonth();
        displayDate.setText(mCalendarView.getYearAndmonth());
    }

    public void turnRight(View v) {
        mCalendarView.clickRightMonth();
        displayDate.setText(mCalendarView.getYearAndmonth());
    }

    public void removeRecord(View view) {
        searchRecordList.clear();
        searchRecordAdapter.notifyDataSetChanged();
        String s = saveSearchRecord(searchRecordList);
        editor.putString(key, s).commit();
    }

    public String saveSearchRecord(Object object) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        String objStr = null;
        try {
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(object);
            objStr = Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);

            oos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return objStr;
    }

    public Object getSearchRecord(String objStr) {
        Object obj = null;
        byte[] strByte = Base64.decode(objStr.getBytes(), Base64.DEFAULT);
        ByteArrayInputStream bais = new ByteArrayInputStream(strByte);
        try {
            ObjectInputStream ois = new ObjectInputStream(bais);
            obj = ois.readObject();
            ois.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return obj;
    }

    public void showInput() {

        mSearchET.postDelayed(new Runnable() {
            @Override
            public void run() {
                imm.showSoftInput(mSearchET, 0);
                controlInput = true;
            }
        }, 200);

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        Log.e("------", "------");
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            closeInput();
        }
        return super.onKeyDown(keyCode, event);
    }

    public void closeInput() {


        if (controlInput) {
            controlInput = false;
            imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }

    public void selectDate(View view) {

        if (calendarWindow != null) {
            calendarWindow.dismiss();
        }

        mCalendarView = (com.schx.ma.userdefineview.CalendarView) calendarContainer.findViewById(R.id.calendar);
        calendarWindow = getPopWindow(calendarContainer, mSearchBar, 2);
        displayDate.setText(mCalendarView.getYearAndmonth());
        mCalendarView.setOnItemClickListener(new com.schx.ma.userdefineview.CalendarView.OnItemClickListener() {
            @Override
            public void OnItemClick(Date date) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String dates = sdf.format(date);
                mSearchET.setText(dates);
                String content = "%" + dates + "%";
                String select = "select jobid from jobinfo where content like ? and state=? and isExist=1 and userid=?";
                Log.e("content", "--" + content);
                String[] vaules = new String[]{content, currentState + "",app.getLoginId()};
                GlobalData.getDBhelper(SearchActivity.this).selectJob(select, vaules, idList);
                calendarWindow.dismiss();
                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putSerializable("idList", idList);
                intent.putExtras(bundle);
                //设置回调的方法
                setResult(1, intent);
                finish();
            }
        });


//            mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
//                @Override
//                public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
//                    date = year + "-" + month + "-" + dayOfMonth;
//                    mSearchET.setText(date);
//                    String content = "%" + date + "%";
//                    String select = "select jobid from jobinfo where content like ?";
//                    Log.e("content", "--" + content);
//                    GlobalData.getDBhelper(SearchActivity.this).selectJob(select, new String[]{content}, idList);
//                    calendarWindow.dismiss();
//                    Intent intent = new Intent();
//                    Bundle bundle = new Bundle();
//                    bundle.putSerializable("idList", idList);
//                    intent.putExtras(bundle);
//                    //设置回调的方法
//                    setResult(1, intent);
//                    finish();
//                }
//            });

    }

    public void selectCondition(View view) {
        String condition = mCategoryTV.getText().toString();
        String select;
        MySQLiteOpenHelper helper = GlobalData.getDBhelper(this);
        if (condition.equals("公司")) {
            select = "select company from jobinfo where state=? and isExist=1 and userid=?";
            listView.setTag(1);
        } else if (condition.equals("地址")) {
            select = "select address from jobinfo where state=? and isExist=1 and userid=?";
            listView.setTag(2);
        } else {
            select = "select mistake from jobinfo where state=? and isExist=1 and userid=?";
            listView.setTag(3);
        }
        String[] values = {currentState + "",app.getLoginId()};
        Log.e("app.getLoginId()","--"+app.getLoginId());
        helper.selectData(select, values, dataList);
        if (searchWarming != null) {
            searchWarming.dismiss();
        }

        searchWarming = getPopWindow(listViewContainer, mSearchBar, 2);

    }

    PopupWindow.OnDismissListener onDismissListener = new PopupWindow.OnDismissListener() {
        @Override
        public void onDismiss() {
            turnWindowLight();
        }
    };

    public void searchWarming(String s) {
        String result = refreshData(s);
        String select = "select content from jobinfo where content like ? and state=? and isExist=1 and userid=?";
        MySQLiteOpenHelper dbHelper = GlobalData.getDBhelper(this);
        String[] values = new String[]{result, currentState + "",app.getLoginId()};
        Log.e("app.getLoginId()","--"+app.getLoginId());
        dbHelper.selectData(select, values, dataList);
        adapter.notifyDataSetChanged();
        if (searchWarming != null) {
            searchWarming.dismiss();
        }
        searchWarming = getPopWindow(listViewContainer, mSearchBar, 1);

        // searchWarming.setFocusable(false);
        // searchWarming.setOnDismissListener(onDismissListener);
    }

    public String refreshData(String s) {
        s.replace(" ", "");
        char[] chars = s.toCharArray();
        String result = "";
        if (chars.length > 0) {
            for (int i = 0; i < chars.length; i++) {
                result += chars[i] + "%";
            }
            result = "%" + result;
        }
        return result;
    }

    public MyPopWindow getPopWindow(View view, View relative, int state) {
        MyPopWindow myPopWindow = null;
        if (state == 1) {
            myPopWindow = new MyPopWindow(view, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);
            myPopWindow.setFocusable(false);
        } else if (state == 2) {
            myPopWindow = new MyPopWindow(view, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);

            myPopWindow.setFocusable(true);
        } else if (state == 3) {
            myPopWindow = new MyPopWindow(view, WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT);
            myPopWindow.setFocusable(true);
        }
        //  myPopWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        Bitmap bitmap = null;
        myPopWindow.setBackgroundDrawable(new BitmapDrawable(getResources(), bitmap));
        myPopWindow.update();
//        if (relative instanceof ViewGroup){
//            ((ViewGroup) relative).removeAllViews();
//        }
        myPopWindow.showAsDropDown(relative, 0, 0);

        return myPopWindow;
    }

    public void select(View view) {

        if (!view.equals(mNullText)) {

            closeInput();
            mSearchET.setFocusable(false);
            mDeleteText.setVisibility(View.INVISIBLE);
            mSearchET.setText("");
            if (view.equals(mDate)) {
                mCalendarIcon.setVisibility(View.VISIBLE);
                mSelectIcon.setVisibility(View.INVISIBLE);
            } else {
                mSelectIcon.setVisibility(View.VISIBLE);
                mCalendarIcon.setVisibility(View.INVISIBLE);
            }
        } else {
            showInput();
            mCalendarIcon.setVisibility(View.INVISIBLE);
            mSelectIcon.setVisibility(View.INVISIBLE);
            mSearchET.setFocusable(true);
            mSearchET.setFocusableInTouchMode(true);
            mSearchET.requestFocus();

        }

        String text = ((TextView) view).getText().toString();
        mCategoryTV.setText(text);
        mMyPopWindow.dismiss();
        turnWindowLight();
    }

    public void search(View v) {
        String content = mSearchET.getText().toString();
        if (!searchRecordList.contains(content) && !content.equals("")) {
            searchRecordList.add(content);
            editor.putString(key, saveSearchRecord(searchRecordList)).commit();
        }
        if (content.equals("")) {
            content = "%%";
        } else {
            content = refreshData(content);
        }
        String select = "select jobid from jobinfo where content like ? and state=? and isExist=1 and userid=?";
        String[] values = new String[]{content, currentState + "",app.getLoginId()};
        GlobalData.getDBhelper(this).selectJob(select, values, idList);
        // getJobFromString();
        if (searchWarming != null) {
            searchWarming.dismiss();
        }
        Intent intent = new Intent();
        Bundle bundle = new Bundle();
        bundle.putSerializable("idList", idList);
        intent.putExtras(bundle);
        //设置回调的方法
        setResult(1, intent);
        finish();
    }

//    public void getJobFromString() {
//
//
//        jobs.clear();
//        for (int i = 0; i < jobStr.size(); i++) {
//            String str = jobStr.get(i);
//            byte[] bytes = str.getBytes();
//            ByteArrayInputStream   bais = new ByteArrayInputStream(bytes);
//            try {
//                ObjectInputStream  ois = new ObjectInputStream(bais);
//                Log.e("job---", "-2" );
//                Job job = (Job) ois.readObject();
//                Log.e("job---", "-" + job);
//                jobs.add(job);
//                ois.close();
//            } catch (ClassNotFoundException e) {
//                e.printStackTrace();
//                Log.e("job---ClassNotFoundE", "-3" );
//            } catch (IOException e) {
//                Log.e("job---IOException", "-3" );
//                e.printStackTrace();
//            }
//
//            Log.e("job---", "-3" );
//        }
//    }

    public class MyPopWindow extends PopupWindow {
        @Override
        public void setContentView(View contentView) {
            super.setContentView(contentView);
        }

        public MyPopWindow(View v, int w, int h) {
            setContentView(v);
            setWidth(w);
            setHeight(h);
        }
    }

    private void turnWindowLight() {
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.alpha = 1;
        getWindow().setAttributes(params);
    }

    private void turnWindowDark() {
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.alpha = 0.8f;
        getWindow().setAttributes(params);
    }
}
