package com.schx.ma.util;

import android.app.Activity;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.schx.ma.R;

import java.util.ArrayList;

/**
 * Created by yuan on 2016/5/24.
 */
public class SearchListAdapter extends BaseAdapter {
    ArrayList<String> data;
    Activity activity;
    LayoutInflater inflater;

    public SearchListAdapter(ArrayList<String> data, Activity activity) {
        this.data = data;
        this.activity = activity;
        inflater = activity.getLayoutInflater();
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.search_list_warm_item, null);
            TextView textWarm = (TextView) convertView.findViewById(R.id.warm_text);
            convertView.setTag(textWarm);
        }
        ((TextView) (convertView.getTag())).setText(data.get(position));
        return convertView;
    }
}
