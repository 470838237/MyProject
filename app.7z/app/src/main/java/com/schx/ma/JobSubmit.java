package com.schx.ma;

import java.util.ArrayList;

/**
 * Created by yuan on 2016/5/19.
 */
public class JobSubmit {
    public int id;
    public String content;
    public String real_reading;
    public String gps_address;
    public String user_id;
    public ArrayList<String> photos;
    public String new_phone;
}
