package com.schx.ma.util;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.schx.ma.GlobalData;
import com.schx.ma.R;
import com.schx.ma.activity.SearchActivity;

import java.util.ArrayList;

/**
 * Created by yuan on 2016/5/26.
 */
public class SearchRecordAdapter extends BaseAdapter {
    LayoutInflater inflater;
    ArrayList<String> data;
    Activity activity;

    public SearchRecordAdapter(ArrayList<String> data, Activity activity) {
        this.inflater = activity.getLayoutInflater();
        this.data = data;
        this.activity = activity;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.size();
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view;
        ViewHolder holder;
        if (convertView == null) {
            view = inflater.inflate(R.layout.search_record_layout, null);
            holder = new ViewHolder();
            holder.iv = (ImageView) view.findViewById(R.id.delete_recordView);
            holder.iv.setTag(position);
            holder.iv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Integer tag = (Integer) v.getTag();
                    data.remove((int) tag);
                    Log.e("---", "----" + tag);
                    SearchRecordAdapter.this.notifyDataSetChanged();

                    ((SearchActivity) activity).editor.putString(((SearchActivity) activity).key,
                            ((SearchActivity) activity).saveSearchRecord(data)).commit();
                }
            });
            holder.tv = (TextView) view.findViewById(R.id.record_textView);
            holder.tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String content = ((TextView) v).getText().toString();
                    String select = "select jobid from jobinfo where content like ? and state=? and isExist=1 and userid=?";
                    Log.e("---", "----holder");
                    content = ((SearchActivity) activity).refreshData(content);
                    String[] values = new String[]{content, SearchActivity.currentState + "", ((SearchActivity) activity).app.getLoginId()};
                    GlobalData.getDBhelper(activity).selectJob(select, values, ((SearchActivity) activity).idList);
                    Intent intent = new Intent();
                    Bundle bundle = new Bundle();
                    ArrayList<Integer> idList = ((SearchActivity) activity).idList;
                    bundle.putSerializable("idList", idList);
                    intent.putExtras(bundle);
                    //设置回调的方法
                    activity.setResult(1, intent);
                    activity.finish();
                }
            });
            view.setTag(holder);
        } else {
            view = convertView;
            holder = (ViewHolder) convertView.getTag();
        }
        holder.tv.setText(data.get(position));
        return view;
    }

    public class ViewHolder {
        TextView tv;
        ImageView iv;
    }
}
