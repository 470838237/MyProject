package com.schx.ma.util;

/**
 * Created by ma on 2015/5/12.
 */
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.BinaryHttpResponseHandler;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

import java.io.File;

public class HttpUtil {
    private static     AsyncHttpClient client =new AsyncHttpClient();    //实例话对象
    static
    {
        client.setTimeout(75000);   //设置链接超时，如果不设置，默认为10s
        client.addHeader("accept", "application/json");
    }
    public static void get(String urlString,AsyncHttpResponseHandler res)    //用一个完整url获取一个string对象
    {
        client.get(urlString, res);
    }
    public static void get(String urlString,RequestParams params,TextHttpResponseHandler res){
        client.get(urlString, params,res);
    }
    public static void post(String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        client.post(url, params, responseHandler);
    }

    public static void get(String urlString,RequestParams params,AsyncHttpResponseHandler res)   //url里面带参数
    {
        client.get(urlString, params,res);
    }
    public static void get(String httpUrl, String urlString, JsonHttpResponseHandler res)   //不带参数，获取json对象或者数组
    {
        client.get(urlString, res);
    }
    public static void get(String urlString,RequestParams params,JsonHttpResponseHandler res)   //带参数，获取json对象或者数组
    {
        client.get(urlString, params,res);
    }
    public static void get(String uString, BinaryHttpResponseHandler bHandler)   //下载数据使用，会返回byte数据
    {
        client.get(uString, bHandler);
    }
    public static AsyncHttpClient getClient()
    {
        return client;
    }

    public static class SQLiteUtil { //SQLite数据库公共函数库

        public static final String SQLite_MASTER_TABLE = "sqlite_master";

        private static SQLiteUtil mInstance = new SQLiteUtil();

        //-------------------------------------------------------------------------
        private SQLiteUtil() {
        }

        //-------------------------------------------------------------------------
        //单例接口
        public static SQLiteUtil getInstance() {
            return (mInstance);
        }

        //-------------------------------------------------------------------------
        //打开数据库
        private SQLiteDatabase openDB(String dbName) {
            File file = new File(dbName);

            Log.d(this.getClass().getName(), file.getAbsolutePath());

            if(file.exists() == true) { //库文件存在则打开数据库
                return (SQLiteDatabase.openDatabase(dbName, null, SQLiteDatabase.OPEN_READWRITE|SQLiteDatabase.NO_LOCALIZED_COLLATORS) );
            }
            else { //如果不存在则初始化
                return(SQLiteDatabase.openOrCreateDatabase(dbName, null) );
            }
        }

        //-------------------------------------------------------------------------
        //关闭数据库
        private void closeDB(SQLiteDatabase db) {
            db.close();
        }

        //-------------------------------------------------------------------------
        //删除数据库
        public boolean deleteDB(String dbName) {
            File file = new File(dbName);

            Log.d(this.getClass().getName(), file.getAbsolutePath() );

            if(file.exists() == true) { //库文件存在则删除
                return (file.delete() );
            }

            return (true);
        }

        //-------------------------------------------------------------------------
        //添加对象
        public void execQuery(String dbName, String sql) {
            SQLiteDatabase db = openDB(dbName);
            db.execSQL(sql);
            closeDB(db);
        }

        //-------------------------------------------------------------------------
        public Cursor openQuery(String dbName, String tableName, String condStr,String orderStr) {
            SQLiteDatabase db = openDB(dbName);
            Cursor cursor = db.query(tableName, null, condStr, null, null, null, orderStr);
            //游标复位
            cursor.moveToFirst();

            //关闭文件
            closeDB(db);

            return (cursor);
        }

        //-------------------------------------------------------------------------
        public int getRowsCount(Cursor cursor) {
            return(cursor.getCount() );
        }

        //-------------------------------------------------------------------------
        public int getColumnsCount(Cursor cursor) {
            return(cursor.getColumnCount() );
        }

        //-------------------------------------------------------------------------
        public String getColumnNameBy(Cursor cursor, int index) {
            return(cursor.getColumnName(index) );
        }

        //-------------------------------------------------------------------------
        public boolean isBOF(Cursor cursor) {
            return(cursor.isBeforeFirst());
        }

        //-------------------------------------------------------------------------
        public boolean isEOF(Cursor cursor) {
            return(cursor.isAfterLast() );
        }

        //-------------------------------------------------------------------------
        public boolean moveNext(Cursor cursor) {
            return(cursor.moveToNext() );
        }

        //-------------------------------------------------------------------------
        public String getField(Cursor cursor, int index) {
            return(cursor.getString(index) );
        }

        //-------------------------------------------------------------------------
        public void closeQuery(Cursor cursor) {
            cursor.close();
        }

        //-------------------------------------------------------------------------
        public boolean isTableExists(String dbName, String tableName) {
            Cursor cursor = openQuery(dbName, SQLite_MASTER_TABLE, "(tbl_name='"+tableName+"')",null);
            int recordCount = cursor.getCount();
            cursor.close();

            return(recordCount > 0);
        }

        //-------------------------------------------------------------------------
    }
}
