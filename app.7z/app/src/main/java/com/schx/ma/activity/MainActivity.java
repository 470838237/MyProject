package com.schx.ma.activity;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.LocationManager;
import android.provider.Settings;
import android.support.v7.app.ActionBarActivity;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.support.v4.widget.DrawerLayout;
import android.view.WindowManager;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Toast;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationListener;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;
import com.schx.ma.GlobalData;
import com.schx.ma.Job;
import com.schx.ma.NavigationDrawerFragment;
import com.schx.ma.R;
import com.schx.ma.userdefineview.RefreshListView;
import com.schx.ma.util.HttpUtil;
import com.schx.ma.util.MySQLiteOpenHelper;
import com.schx.ma.util.JobPreviewAdapter;
import com.schx.ma.util.hexutil;

import org.apache.http.Header;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;


public class MainActivity extends ActionBarActivity implements
        NavigationDrawerFragment.NavigationDrawerCallbacks,
        AMapLocationListener {
    final static int WAIT_DEAL = 1;
    final static int VIEW_JOB = 2;
    final static int CREATE_JOB = 3;
    public static int currentState = 1;
    public static int currentPage = 1;
    //    final static String WAIT_DEAL_KEY = "WAIT_DEAL";
//    final static String VIEW_JOB_KEY = "VIEW_JOB";
//    final static String CREATE_JOB_KEY = "CREATE_JOB";

    public static GlobalData appdata;

    ArrayList<Job> exchange = new ArrayList<Job>();


    /**
     * Fragment managing the behaviors, interactions and presentation of the navigation drawer.
     */
    private NavigationDrawerFragment mNavigationDrawerFragment;

    /**
     * Used to store the last screen title. For use in .
     */
    private CharSequence mTitle;
    //声明AMapLocationClient类对象
    public AMapLocationClient mLocationClient = null;
    //声明mLocationOption对象
    public AMapLocationClientOption mLocationOption = null;
    private String mCurrentAddress = "";

    private static OnUpdateDataListener listener;
    private static LocationRefresh locationRefresh;
    private static boolean isSearch = false;
    public HashMap<Integer, RefreshListViewHeader> headerMap;

    public static String sHA1(Context context) {
        try {
            PackageInfo info = context.getPackageManager().getPackageInfo(
                    context.getPackageName(), PackageManager.GET_SIGNATURES);
            byte[] cert = info.signatures[0].toByteArray();
            MessageDigest md = MessageDigest.getInstance("SHA1");
            byte[] publicKey = md.digest(cert);
            StringBuffer hexString = new StringBuffer();
            for (int i = 0; i < publicKey.length; i++) {
                String appendString = Integer.toHexString(0xFF & publicKey[i])
                        .toUpperCase(Locale.US);
                if (appendString.length() == 1)
                    hexString.append("0");
                hexString.append(appendString);
            }
            return hexString.toString();
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return null;
    }

    AdapterView.OnItemClickListener onItemClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Integer state = (Integer) parent.getTag();
            if (position == 0) {
                if (isSearch) {
                    headerMap.get(currentState).datas.clear();
                    headerMap.get(currentState).datas.addAll(exchange);
                }
                Intent intents = new Intent(MainActivity.this, SearchActivity.class);
                intents.putExtra("state", state);
                startActivityForResult(intents, 2);
            } else {
                Intent intent = new Intent(MainActivity.this, JobActivity.class);
                Job job = headerMap.get(currentState).datas.get(position - 1);
                intent.putExtra("job", new Gson().toJson(job));
                intent.putExtra("address", mCurrentAddress);
                intent.putExtra("state", state);
                intent.putExtra("index", position - 1);
                startActivityForResult(intent, 1);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        appdata = (GlobalData) getApplication();
        headerMap = new HashMap<Integer, RefreshListViewHeader>();
        Log.e("sHA1", "--" + sHA1(this));
        setTitle(getString(R.string.title_section1) + "(0)");

        mNavigationDrawerFragment = (NavigationDrawerFragment)
                getSupportFragmentManager().findFragmentById(R.id.navigation_drawer);
        mTitle = getTitle();
        setTitleColor(Color.YELLOW);
        init_locate();
        // Set up the drawer.
        mNavigationDrawerFragment.setUp(
                R.id.navigation_drawer,
                (DrawerLayout) findViewById(R.id.drawer_layout));
        //onQueryClick(null);
        //为数据绑定适配器
        ArrayList<Job> datas = new ArrayList<Job>();
        JobPreviewAdapter mAdapter = new JobPreviewAdapter(datas, MainActivity.this);
        // 绑定XML中的ListView，作为Item的容器
        RefreshListView listView = (RefreshListView) findViewById(R.id.listView_jobs);
        RefreshListViewHeader waitHeader = new RefreshListViewHeader(this, listView, mAdapter, datas);
        waitHeader.setDisplayState((TextView) findViewById(R.id.wait_deal));
        headerMap.put(WAIT_DEAL, waitHeader);
        listView.setTag(WAIT_DEAL);
        listView.setAdapter(mAdapter);
        //添加点击
        listView.setOnItemClickListener(onItemClickListener);
    }

    public void setRefreshListener(RefreshListView listView) {
        Integer temp = (Integer) listView.getTag();
        currentState = temp;
        Log.e("temp", "---" + currentState);
    }

    private void init_locate() {
        //初始化定位
        mLocationClient = new AMapLocationClient(getApplicationContext());
        //mCurrentAddress=mLocationClient.getLastKnownLocation().getAddress();
        //设置定位回调监听
        mLocationClient.setLocationListener(this);
        //初始化定位参数
        mLocationOption = new AMapLocationClientOption();
        //设置定位模式为高精度模式，Battery_Saving为低功耗模式，Device_Sensors是仅设备模式
        mLocationOption.setLocationMode(AMapLocationClientOption.AMapLocationMode.Hight_Accuracy);
        //设置是否返回地址信息（默认返回地址信息）
        mLocationOption.setNeedAddress(true);
        //设置是否只定位一次,默认为false
        mLocationOption.setOnceLocation(false);
        //设置是否强制刷新WIFI，默认为强制刷新
        mLocationOption.setWifiActiveScan(true);
        //设置是否允许模拟位置,默认为false，不允许模拟位置
        mLocationOption.setMockEnable(false);
        //设置定位间隔,单位毫秒,默认为60000ms
        mLocationOption.setInterval(10000);
        //给定位客户端对象设置定位参数
        mLocationClient.setLocationOption(mLocationOption);
        //启动定位
        mLocationClient.startLocation();

    }

    // 定位监听
    @Override
    public void onLocationChanged(AMapLocation amapLocation) {
        if (amapLocation != null) {
            if (amapLocation.getErrorCode() == 0) {
                //定位成功回调信息，设置相关消息
                amapLocation.getLocationType();//获取当前定位结果来源，如网络定位结果，详见定位类型表
                amapLocation.getLatitude();//获取纬度
                amapLocation.getLongitude();//获取经度
                amapLocation.getAccuracy();//获取精度信息
                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date date = new Date(amapLocation.getTime());
                df.format(date);//定位时间
                amapLocation.getAddress();//地址，如果option中设置isNeedAddress为false，则没有此结果，网络定位结果中会有地址信息，GPS定位不返回地址信息。
                amapLocation.getCountry();//国家信息
                amapLocation.getProvince();//省信息
                amapLocation.getCity();//城市信息
                amapLocation.getDistrict();//城区信息
                amapLocation.getStreet();//街道信息
                amapLocation.getStreetNum();//街道门牌号信息
                amapLocation.getCityCode();//城市编码
                amapLocation.getAdCode();//地区编码
                amapLocation.getAoiName();//获取当前定位点的AOI信息
                mCurrentAddress = amapLocation.getAddress() + amapLocation.getStreetNum();

                if (!mCurrentAddress.equals("")) {
                    locationRefresh.locationRefresh(mCurrentAddress);
                }
            } else {
                //显示错误信息ErrCode是错误码，errInfo是错误信息，详见错误码表。
                Log.e("AmapError", "location Error, ErrCode:"
                        + amapLocation.getErrorCode() + ", errInfo:"
                        + amapLocation.getErrorInfo());
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent intent) {

        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                int finished_index = intent.getIntExtra("index", -1);
                //从待处理列表中删除该id
                Job job = headerMap.get(currentState).datas.get(finished_index);
                headerMap.get(currentState).datas.remove(job);
                headerMap.get(currentState).adapter.notifyDataSetChanged();
                GlobalData.getDBhelper(MainActivity.this).deleteData(new String[]{job.getId() + "", currentState + "", appdata.getLoginId()});
                changeTitle();
            }
        }
        if (requestCode == 2) {
            if (resultCode == 1) {
                ArrayList<Integer> idList = (ArrayList<Integer>) intent.getExtras().getSerializable("idList");
                ArrayList<Job> temp = new ArrayList<Job>();
                for (int i = 0; i < idList.size(); i++) {
                    for (int j = 0; j < headerMap.get(currentState).datas.size(); j++) {
                        if (idList.get(i) == headerMap.get(currentState).datas.get(j).getId()) {
                            temp.add(headerMap.get(currentState).datas.get(j));
                        }
                    }
                }
                exchange.clear();
                exchange.addAll(headerMap.get(currentState).datas);
                headerMap.get(currentState).datas.clear();
                headerMap.get(currentState).datas.addAll(temp);
                headerMap.get(currentState).adapter.notifyDataSetChanged();
                isSearch = true;
            }
        }
    }

    public ProgressDialog getPro(View view, String text) {
        ProgressDialog dialog = null;
        if (view == null) {
            dialog = ProgressDialog.show(this, "请稍等", text);
        } else {
            headerMap.get(currentState).datas.clear();
            currentPage = 1;
        }
        return dialog;
    }

    public void onQueryClick(final View view) {
        String HttpUrl = null;
        RequestParams params = new RequestParams();
        String text = null;
        if (currentState == WAIT_DEAL) {
            HttpUrl = appdata.getBaseUrl() + "/appv1/index?";
            params.put("user_id", appdata.getLoginId());
            text = "正在进行查询待处理维修单...";
        } else if (currentState == VIEW_JOB) {
            HttpUrl = appdata.getBaseUrl() + "/appv1/finished_index?";
            params.put("user_id", appdata.getLoginId());
            params.put("page", currentPage);
            text = "正在进行查询已完成维修单...";
        }

        final ProgressDialog pDialog = getPro(view, text);
        HttpUtil.get("", new TextHttpResponseHandler() {
            @Override
            public void onFailure(int i, Header[] headers, String s, Throwable throwable) {

            }

            @Override
            public void onSuccess(int i, Header[] headers, String s) {

            }
        });
        HttpUtil.get(HttpUrl, params, new JsonHttpResponseHandler() {
            public void onFinish() { // 完成后调用，失败，成功，都要掉
                if (pDialog != null) {
                    pDialog.dismiss();
                }
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                super.onSuccess(statusCode, headers, response);
                doServerQueryResult(response, view);
                isSearch = false;
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                super.onFailure(statusCode, headers, throwable, errorResponse);
                Log.e("errorResponse", "" + errorResponse);
                Log.e("errorResponse", "" + throwable);
                String text = "";
                if (throwable != null)
                    text = (text + throwable);

                headerMap.get(currentState).refreshFail(text);
                changeTitle();
            }
        });
    }

    private void doServerQueryResult(JSONArray jsonObjs, View view) {
        if (currentState==1)
            headerMap.get(currentState).datas.clear();
        try {
            Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
            for (int i = 0; i < jsonObjs.length(); i++) {
                JSONObject jsonJob = jsonObjs.getJSONObject(i);
                Job job = gson.fromJson(jsonJob.toString(), Job.class);
                if (job != null) {
                    headerMap.get(currentState).datas.add(job);
                    if (!GlobalData.getFinishedJob().contains(job) && currentState == 2) {
                        GlobalData.getFinishedJob().add(job);
                    }
                }
            }

            headerMap.get(currentState).adapter.notifyDataSetChanged();
            headerMap.get(currentState).refreshSuccess(view);
            new Thread() {
                public void run() {
                    saveData2DB();
                }
            }.start();

            changeTitle();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void changeTitle() {
        String title = null;
        if (currentState == 1) {
            title = getString(R.string.title_section1);
        } else if (currentState == 2) {
            title = getString(R.string.title_section2);
        }
        setTitle(title + "(" + headerMap.get(currentState).datas.size() + ")");
        listener.onUpdateDataListener(headerMap.get(currentState).datas, appdata, currentState);
    }

    public void saveData2DB() {
        String insert = "insert into jobinfo(jobid,company,address,mistake,date,object,state,content,isExist,userid) values(?,?,?,?,?,?,?,?,?,?) ";
        MySQLiteOpenHelper mySQLiteOpenHelper = GlobalData.getDBhelper(this);
        for (int i = 0; i < headerMap.get(currentState).datas.size(); i++) {
            Job job = headerMap.get(currentState).datas.get(i);
            String content = job.getCompany().getName() + "   " + job.getAddress() + "   " + job.getMain_error().getName()
                    + "   " + hexutil.dateToString(job.getCreated_at());
            String object = object2String(job);
            String state = currentState + "";
            String[] data = {job.getId() + "", job.getCompany().getName(), job.getAddress(),
                    job.getMain_error().getName(), hexutil.dateToString(job.getCreated_at()), object, state, content, 1 + "", appdata.getLoginId()};
            if (!mySQLiteOpenHelper.isDataExist(new String[]{job.getId() + "", currentState + "", appdata.getLoginId()})) {
                mySQLiteOpenHelper.insertData(insert, data);
            }
        }
    }

    public String object2String(Job job) {
        String temp;

        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(baos);

        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            oos.writeObject(job);
        } catch (IOException e) {
            e.printStackTrace();
        }
        temp = new String(baos.toByteArray());
        return temp;
    }

    // 1.首先会调用Activity的dispatchTouchEvent()方法
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
            onUserInteraction();
        }
        if (getWindow().superDispatchTouchEvent(ev)) {
            return true;
        }
    /*
     * 如果没有view去处理，即getWindow().superDispatchTouchEvent(ev)返回为false
     * 则调用当前activity的onTouchEvent()方法
     */
        return onTouchEvent(ev);
    }


    @Override
    public void onNavigationDrawerItemSelected(int position) {
        // update the main content by replacing fragments
        FragmentManager fragmentManager = getSupportFragmentManager();


        fragmentManager.beginTransaction()
                .replace(R.id.container, PlaceholderFragment.newInstance(position + 1))
                .commit();

    }

    public void onSectionAttached(int number) {
        switch (number) {
            case 1:
                //  mTitle = getString(R.string.title_section1) + "(" + appdata.getRealName() + ")";

                Log.e("com.schx.ma----", "clicked " + mTitle);
                break;
            case 2:
                //mTitle = getString(R.string.title_section2);

                Log.d("com.schx.ma", "clicked " + mTitle);
                break;
            case 3:
                //mTitle = getString(R.string.title_section3);
                onNewJobClick(null);
                Log.d("com.schx.ma", "clicked " + mTitle);
                break;
            case 4:
                //mTitle = getString(R.string.title_section4);
                onSettingOnclik();
                break;
            case 5:
                // mTitle = getString(R.string.title_section5);
                onLoginOutClick(null);
                Log.d("com.schx.ma", "clicked " + mTitle);
                break;
        }
    }

    public void onSettingOnclik() {

    }

    private void onLoginOutClick(View view) {
        appdata.clearSetting();
        this.finish();
    }

    private void onNewJobClick(View view) {

    }

    private void onFinishedJobClick(View view) {


    }

    @Override
    protected void onDestroy() {
        GlobalData.getFinishedJob().clear();
        super.onDestroy();
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {
        MainActivity activity;
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final String ARG_SECTION_NUMBER = "section_number";


        public PlaceholderFragment() {

        }

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static PlaceholderFragment newInstance(int sectionNumber) {

            PlaceholderFragment fragment = new PlaceholderFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);

            return fragment;
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            int position = getArguments().getInt(ARG_SECTION_NUMBER);
            getActivity();
            View rootView = null;
            activity = (MainActivity) getActivity();
            //点击不同侧滑单元抽取不同布局
            switch (position) {
                case 1:
                    activity.setRefreshListener(activity.headerMap.get(MainActivity.WAIT_DEAL).listView);
                    activity.onQueryClick(null);
                    rootView = null;
                    break;
                case 2:
                    activity.setTitle(getResources().getString(R.string.title_section2) + "(0)");
                    rootView = inflater.inflate(R.layout.fragment_main, container, false);
                    RefreshListView listViewViewJobs = (RefreshListView) rootView.findViewById(R.id.view_jobs);

                    listViewViewJobs.setonPageChangeListenter(new RefreshListView.CallBack() {
                        @Override
                        public int onPageChangeListenter() {

                            currentPage++;
                            activity.onQueryClick(null);
                            return 0;
                        }
                    });
                    listViewViewJobs.setTag(MainActivity.VIEW_JOB);
                    listViewViewJobs.setOnItemClickListener(activity.onItemClickListener);
                    ArrayList<Job> datas = new ArrayList<Job>();
                    JobPreviewAdapter adapter = new JobPreviewAdapter(datas, activity);
                    RefreshListViewHeader headerView = new RefreshListViewHeader(activity, listViewViewJobs, adapter, datas);
                    headerView.setDisplayState((TextView) rootView.findViewById(R.id.finish_deal));

                    activity.headerMap.put(MainActivity.VIEW_JOB, headerView);
                    listViewViewJobs.setAdapter(adapter);
                    activity.setRefreshListener(listViewViewJobs);
                    Log.e("getFinishedJob", "-" + GlobalData.getFinishedJob().size());
                    if (GlobalData.getFinishedJob().size() == 0) {
                        activity.onQueryClick(null);
                    } else {
                        activity.setTitle(getResources().getString(R.string.title_section2) + "(" + GlobalData.getFinishedJob().size() + ")");
                        headerView.datas = GlobalData.getFinishedJob();
                        headerView.adapter = new JobPreviewAdapter(GlobalData.getFinishedJob(), activity);
                        headerView.listView.setAdapter(headerView.adapter);
                        listener.onUpdateDataListener(headerView.datas, activity.appdata, currentState);
                    }
                    break;
                case 3:

//                    rootView = inflater.inflate(R.layout.fragment_main, container, false);
//                    rootView.setBackgroundColor(Color.YELLOW);
                    break;
                case 4:
//                    rootView = inflater.inflate(R.layout.fragment_main, container, false);
//                    rootView.setBackgroundColor(Color.BLUE);
                    break;
                default:
                    rootView = null;
                    break;
            }

            return rootView;
        }

        @Override
        public void onAttach(Activity activity) {
            super.onAttach(activity);
            ((MainActivity) activity).onSectionAttached(
                    getArguments().getInt(ARG_SECTION_NUMBER));
        }
    }


    /**
     * 判断GPS是否开启，若未开启，则进入GPS设置页面；设置完成后需用户手动回界面
     *
     * @param context
     * @return
     */
    public static void openGPSSettings(Context context) {
        //获取位置服务
        LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        //若GPS未开启
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Toast.makeText(context, "请开启GPS！", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            context.startActivity(intent);
        }
    }

    public interface OnUpdateDataListener {
        void onUpdateDataListener(ArrayList<Job> list, GlobalData globalData, int currentState);
    }

    public static void setOnUpdateDataListener(OnUpdateDataListener listener) {
        MainActivity.listener = listener;
    }

    public interface LocationRefresh {
        void locationRefresh(String location);
    }

    public static void setLocationListener(LocationRefresh locationRefresh) {
        MainActivity.locationRefresh = locationRefresh;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && isSearch) {
            isSearch = false;

            final View view1 = getRootView(this);
            WindowManager wm1 = this.getWindowManager();
            final int width = wm1.getDefaultDisplay().getWidth();
            TranslateAnimation animation = new TranslateAnimation(width, 0, 0, 0);
            animation.setDuration(300);
            view1.startAnimation(animation);
            headerMap.get(currentState).datas.clear();
            headerMap.get(currentState).datas.addAll(exchange);
            headerMap.get(currentState).adapter.notifyDataSetChanged();

            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private static View getRootView(Activity context) {
        return ((ViewGroup) context.findViewById(android.R.id.content)).getChildAt(0);
    }
}
