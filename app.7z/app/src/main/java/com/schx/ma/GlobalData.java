package com.schx.ma;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;

import com.schx.ma.util.MySQLiteOpenHelper;

import java.net.UnknownHostException;
import java.util.ArrayList;

/**
 * Created by ma on 2016/3/21.
 */
public class GlobalData extends Application {
    private String LoginId;
    private String UserName;
    private String RealName;
    private String Role;
    private String BaseUrl;
    private static String DB_NAME="schxkj.db3";
    private static MySQLiteOpenHelper mDBhlper;
    private static ArrayList<String> pathList;
    private static ArrayList<Job> finishedJob;

    public String getBaseUrl() {
        //return "http://192.168.5.103:3000";
        return "http://schxkjnet.gicp.net:67";//正式服务器IP和端口号
        //测试用户名hujun ,密码123
        //return "http://192.168.1.12:6700";//测试数据服务器

    }

    @Override
    public void onCreate() {
        //首次登陆后，保存用户信息到配置文件。启动后从配置文件中读取。获取SharedPreferences对象
        Context ctx = getApplicationContext();
        SharedPreferences sp = ctx.getSharedPreferences("gcwh", MODE_PRIVATE);
        String saved_name=sp.getString("name", "");
        String saved_real_name=sp.getString("real_name", "");
        String saved_password=sp.getString("password", "");
        String saved_login_id=sp.getString("login_id","");
        String saved_role=sp.getString("role","");
        pathList=new ArrayList<String>();

        //验证
        if(saved_name.length()>0 && saved_password.length()>0){
            setLoginId(saved_login_id);
            setUserName(saved_name);
            setRealName(saved_real_name);
            setRole(saved_role);
        }

        super.onCreate();
    }
    public static  ArrayList<Job> getFinishedJob(){
        if(finishedJob==null){
            finishedJob=new ArrayList<Job>();
        }
        return finishedJob;
    }
    public  static MySQLiteOpenHelper getDBhelper(Context context){
        if(mDBhlper==null){
            mDBhlper=new MySQLiteOpenHelper(context,DB_NAME,2);
        }
        return mDBhlper;
    }
    public void clearSetting(){
        SharedPreferences mySharedPreferences = getSharedPreferences("gcwh", Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = mySharedPreferences.edit();
        editor.clear();
        editor.commit();
        setLoginId("");
        setUserName("");
        setRealName("");
        setRole("");

    }
    public String getLoginId() {
        return LoginId;
    }

    public void setLoginId(String loginId) {
        LoginId = loginId;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getRealName() {
        return RealName;
    }

    public void setRealName(String realName) {
        RealName = realName;
    }

    public String getRole() {
        return Role;
    }

    public void setRole(String role) {
        Role = role;
    }
    public static String convertStateCode(int state_number) {
        String state = "";
        if (state_number==0) {
            state = "新建";
        }
        if (state_number==1) {
            state = "已维修";
        }
        if (state_number==2) {
            state = "主管已审";
        }
        if (state_number==3) {
            state = "经理已审";
        }

        return state;
    }
    public static void savePathList(ArrayList<String> list){
        GlobalData.pathList=list;
    }
    public static  ArrayList<String> getPathList(){
        return GlobalData.pathList;
    }
}
