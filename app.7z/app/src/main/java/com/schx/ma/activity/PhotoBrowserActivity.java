package com.schx.ma.activity;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.schx.ma.R;
import com.schx.ma.util.MyPagerAdapter;

import java.util.ArrayList;

public class PhotoBrowserActivity extends Activity {
    ViewPager viewPager;
    ArrayList<String> mPhotoURi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_photo_brower);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        viewPager= (ViewPager) findViewById(R.id.viewPager);
        mPhotoURi=getIntent().getStringArrayListExtra("mPhotoURi");
        int index=getIntent().getIntExtra("index",0);
        MyPagerAdapter adapter=new MyPagerAdapter(index,mPhotoURi,this);
        viewPager.setAdapter(adapter);
        viewPager.setCurrentItem(index);
    }
}
