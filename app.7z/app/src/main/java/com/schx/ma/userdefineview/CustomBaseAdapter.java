package com.schx.ma.userdefineview;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.schx.ma.R;

import java.util.ArrayList;
import java.util.HashMap;
/**
 * Created by Administrator on 2016/5/9 0009.
 */
public class CustomBaseAdapter extends BaseAdapter {
    ArrayList<HashMap<String, Object>> items;
    LayoutInflater inflater;
    public CustomBaseAdapter(ArrayList<HashMap<String, Object>> items,LayoutInflater inflater){
        this.items = items;
        this.inflater=inflater;
    }
    boolean flag=true;
    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView==null){
            convertView=inflater.inflate( R.layout.menu_list_item_model,null);
            holder=new ViewHolder();
            holder.iv= (ImageView) convertView.findViewById(R.id.image_item);
            holder.tv= (TextView) convertView.findViewById(R.id.textView);
            convertView.setTag(holder);
        }else{
            holder= (ViewHolder) convertView.getTag();
        }
        if(position==0&&flag){
            convertView.setBackgroundResource(R.color.coral);
            flag=false;
        }
        holder.iv.setImageResource((Integer)items.get(position).get("icon"));
        holder.tv.setText((String)items.get(position).get("name"));
        return convertView;
    }
    public class ViewHolder{
        ImageView iv;
        TextView tv;

    }
}
