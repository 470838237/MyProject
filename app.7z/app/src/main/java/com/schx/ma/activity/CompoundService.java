package com.schx.ma.activity;

import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.os.IBinder;
import android.util.Log;

import com.schx.ma.Job;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class CompoundService extends Service {
    public CompoundService() {
    }

    @Override
    public IBinder onBind(Intent intent) {

        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.e("onStartCommand", "  onStartCommand ");
        final String path = intent.getStringExtra("path");
        new Thread() {
            @Override
            public void run() {
                getImageFromPhoto(path);
                Log.e("onBind", "" + path);
            }
        }.start();
        return super.onStartCommand(intent, flags, startId);
    }

    //读取图片添加水印并写入
    public void getImageFromPhoto(String path) {
        FileInputStream fis=null;
        try {
             fis=new FileInputStream(path);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        BitmapFactory.Options options=new BitmapFactory.Options();
        options.inSampleSize=2;
        Bitmap bitmap = BitmapFactory.decodeStream(fis,new Rect(-1,-1,-1,-1),options);
        bitmap = JobActivity.compoundImage(bitmap);
        try {
            FileOutputStream fos = new FileOutputStream(new File(path));
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
