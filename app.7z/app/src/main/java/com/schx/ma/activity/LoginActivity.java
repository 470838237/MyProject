package com.schx.ma.activity;

import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.schx.ma.GlobalData;
import com.schx.ma.R;
import com.schx.ma.User;
import com.schx.ma.util.HttpUtil;
import com.schx.ma.util.hexutil;

import org.apache.http.Header;
import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends Activity {
    private EditText edtUserName, edtPassword;
    private GlobalData appdata;
    private ProgressDialog pDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ActionBar actionBar = getActionBar();
        actionBar.hide();
        appdata = (GlobalData) getApplication();
        edtUserName = (EditText) findViewById(R.id.editText_username);
        edtPassword = (EditText) findViewById(R.id.editText_password);
        adjustIcon();
        //检查本地登录信息
        checkLocalLogin();
    }

    //调整EditText内drawable大小
    public void adjustIcon() {
        Drawable drawableUser = getResources().getDrawable(R.drawable.user);
        drawableUser.setBounds(0, 0, 100, 100);
        edtUserName.setCompoundDrawables(drawableUser, null, null, null);
        Drawable drawablePassWord = getResources().getDrawable(R.drawable.password);
        drawablePassWord.setBounds(0, 0, 100, 100);
        edtPassword.setCompoundDrawables(drawablePassWord, null, null, null);
    }

    private boolean checkLocalLogin() {
        //获取SharedPreferences对象
        Context ctx = LoginActivity.this;
        SharedPreferences sp = ctx.getSharedPreferences("gcwh", MODE_PRIVATE);
        String saved_name = sp.getString("name", "");
        String saved_password = sp.getString("password", "");
        String saved_login_id = sp.getString("login_id", "");
        String saved_real_name = sp.getString("real_name", "");
        String saved_role = sp.getString("role", "");
        Log.d("com.schx.ma", "saved_name=" + saved_name + ",saved_password=" + saved_password);
        if (saved_name.length() > 0 && saved_password.length() > 0) {
            appdata.setLoginId(saved_login_id);
            appdata.setUserName(saved_name);
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
            return true;
        }
        return false;
    }

    public void onExitClicked(View view) {
        finish();
    }

    public void onLoginClicked(View view) {
        String name, password;
        name = edtUserName.getText().toString().trim();
        password = edtPassword.getText().toString().trim();
        if (name.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "用户名或密码不能为空，请修改！", Toast.LENGTH_SHORT).show();
            return;
        }
        serverLoginCertify(name, password);

    }

    private int serverLoginCertify(String name, String password) {

        String HttpUrl = appdata.getBaseUrl() + "/appv1/login?";
        RequestParams params = new RequestParams(); // 绑定参数
        params.put("loginname", name);
        params.put("password", password);
        pDialog = ProgressDialog.show(this, "请稍等", "正在进行登录验证...");
        HttpUtil.get(HttpUrl, params, new JsonHttpResponseHandler() {
            public void onFinish() { // 完成后调用，失败，成功，都要掉
                pDialog.dismiss();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                super.onSuccess(statusCode, headers, response);
                doServerLoginResult(response);
                Log.i("serverLoginCertify", response.toString());
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                super.onFailure(statusCode, headers, throwable, errorResponse);
                if (errorResponse != null) {
                    try {
                        Toast.makeText(LoginActivity.this, "登录失败," + errorResponse.getString("error"),
                                Toast.LENGTH_LONG).show();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {
                    Toast.makeText(LoginActivity.this, "登录失败," + throwable.getMessage(),
                            Toast.LENGTH_LONG).show();
                }

            }

        });
        return 0;
    }

    private void doServerLoginResult(JSONObject response) {

        //登录成功,写入配置文件
        Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss").create();
        String user_json = null;
        try {
            user_json = response.getString("user");
            User user = gson.fromJson(user_json, User.class);
            //保存
            SharedPreferences mySharedPreferences = getSharedPreferences("gcwh",
                    Activity.MODE_PRIVATE);
            SharedPreferences.Editor editor = mySharedPreferences.edit();
            editor.putString("name", user.getName());
            editor.putString("password", hexutil.stringMD5(user.getPassword()));
            editor.putString("login_id", Integer.toString(user.getId()));
            editor.putString("role", user.getRole());
            editor.putString("real_name", user.getReal_name());
            editor.commit();
            appdata.setLoginId(Integer.toString(user.getId()));
            appdata.setUserName(user.getName());
            appdata.setRealName(user.getReal_name());
            appdata.setRole(user.getRole());
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

}
