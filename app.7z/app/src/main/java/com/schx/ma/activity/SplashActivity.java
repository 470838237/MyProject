package com.schx.ma.activity;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.util.Xml;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Toast;

import com.loopj.android.http.TextHttpResponseHandler;
import com.schx.ma.GlobalData;
import com.schx.ma.R;
import com.schx.ma.UpdataInfo;
import com.schx.ma.UpdateService;
import com.schx.ma.util.HttpUtil;

import org.apache.http.Header;
import org.xmlpull.v1.XmlPullParser;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

public class SplashActivity extends Activity {
    private static final int DOWN_ERROR = 1;
    private static final int  UPDATA_CLIENT=2;
    private static final int GET_UNDATAINFO_ERROR=3;
    private UpdataInfo info;
    private String TAG="com.schx.ma";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getActionBar();
        actionBar.hide();

        //获取activity_splash_page.xml布局
        View view = View.inflate(this, R.layout.activity_splash, null);
        //加载布局
        setContentView(view);

        //设置动画，渐显渐隐可用AlphaAnimation,变形动画用RotateAnimation,位移动画用TranslateAnimation
        //第一个参数值0.8f为开始的透明度为30%，第二个参数值1.0f为结束的透明度为100%，即不透明。
        AlphaAnimation alphaAnimation = new AlphaAnimation(0.8f, 1.0f);

        //给动画设置持续时间，如果不设置，则时间为0，动画就看不到效果
        alphaAnimation.setDuration(3000);

        //给我们的背景运行动画
        view.startAnimation(alphaAnimation);
        //设置动画监听
        alphaAnimation.setAnimationListener(new Animation.AnimationListener() {

            @Override  //动画一开始就执行以下方法
            public void onAnimationStart(Animation animation) {
                checkUpdateServerUrl();
            }

            @Override //动画重复时执行以下方法
            public void onAnimationRepeat(Animation animation) {
            }

            @Override //动画结束时执行以下方法
            public void onAnimationEnd(Animation animation) {
                //在此填写执行跳转到其他页面的语句
                gotoLoginWindow();

            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    private void checkUpdateServerUrl(){
        GlobalData globalData=(GlobalData) getApplication();
        final String HttpUrl =globalData.getBaseUrl()+"/update.xml";
        HttpUtil.get(HttpUrl, new TextHttpResponseHandler() {

            @Override
            public void onFinish() {
                Log.i(TAG, "onFinish");
            }

            @Override
            public void onFailure(int i, Header[] headers, String s, Throwable throwable) {
                Log.i(TAG, "onFailure检查升级信息失败" + throwable.getMessage() + "," + HttpUrl);
                gotoLoginWindow();
            }

            @Override
            public void onSuccess(int i, Header[] headers, String s) {
                Log.i("检查升级信息", s);
                doCheckUpgradeServerQueryResult(s);
                
            }
        });
    }
    private void doCheckUpgradeServerQueryResult(String s) {
        try {
            InputStream stream = new ByteArrayInputStream(s.getBytes());
            info = getUpdataInfo(stream);

            String versionname = getVersionName();
            float serverVersion = Float.valueOf(info.getVersion());
            float localVersion = Float.valueOf(versionname);
            Log.d(TAG,"serverVersion="+serverVersion+",localVersion="+localVersion+",versionname="+versionname);
            if(serverVersion<=localVersion){
                Log.i(TAG, "版本号相同无需升级");
                gotoLoginWindow();
            }else{
                Log.i(TAG,"版本号不同 ,提示用户升级 ");
                //对话框通知用户升级程序
                showUpdataDialog();
            }
        }catch (Exception e){

        }

    }


    private String getVersionName() throws Exception{
        //获取packagemanager的实例
        PackageManager packageManager = getPackageManager();
        //getPackageName()是你当前类的包名，0代表是获取版本信息
        PackageInfo packInfo = packageManager.getPackageInfo(getPackageName(), 0);
        return packInfo.versionName;
    }
    /*
 * 用pull解析器解析服务器返回的xml文件 (xml封装了版本号)
 */
    public static UpdataInfo getUpdataInfo(InputStream is) throws Exception{
        XmlPullParser parser = Xml.newPullParser();
        parser.setInput(is, "utf-8");//设置解析的数据源
        int type = parser.getEventType();
        UpdataInfo info = new UpdataInfo();//实体
        while(type != XmlPullParser.END_DOCUMENT ){
            switch (type) {
                case XmlPullParser.START_TAG:
                    if("version".equals(parser.getName())){
                        info.setVersion(parser.nextText()); //获取版本号
                    }else if ("url".equals(parser.getName())){
                        info.setUrl(parser.nextText()); //获取要升级的APK文件
                    }else if ("description".equals(parser.getName())){
                        info.setDescription(parser.nextText()); //获取该文件的信息
                    }

                    break;
            }
            type = parser.next();
        }
        return info;
    }


    Handler handler = new Handler(){

        @Override
        public void handleMessage(Message msg) {
            // TODO Auto-generated method stub
            super.handleMessage(msg);
            switch (msg.what) {
                case UPDATA_CLIENT:
                    //对话框通知用户升级程序
                    showUpdataDialog();
                    break;
                case GET_UNDATAINFO_ERROR:
                    //服务器超时
                    Toast.makeText(getApplicationContext(), "获取服务器更新信息失败", Toast.LENGTH_SHORT).show();
                    gotoLoginWindow();
                    break;
                case DOWN_ERROR:
                    //下载apk失败
                    Toast.makeText(getApplicationContext(), "下载新版本失败", Toast.LENGTH_SHORT).show();
                    gotoLoginWindow();
                    break;
            }
        }
    };
    /*
 *
 * 弹出对话框通知用户更新程序
 *
 * 弹出对话框的步骤：
 *  1.创建alertDialog的builder.
 *  2.要给builder设置属性, 对话框的内容,样式,按钮
 *  3.通过builder 创建一个对话框
 *  4.对话框show()出来
 */
    protected void showUpdataDialog() {

        String msg=info.getDescription();
        msg=msg.replaceAll("[\\\\r\\\\n]+","\n");

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("版本升级");
        builder.setMessage(msg);
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // TODO Auto-generated method stub
                Log.i(TAG, "下载apk,更新");
                //downLoadApk();
                //开启更新服务UpdateService
                //这里为了把update更好模块化，可以传一些updateService依赖的值
                //如布局ID，资源ID，动态获取的标题,这里以app_name为例
                Intent updateIntent = new Intent(SplashActivity.this, UpdateService.class);
                updateIntent.putExtra("update_file_url", info.getUrl());
                startService(updateIntent);
                gotoLoginWindow();
            }
        });
        builder.setNegativeButton("取消",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                gotoLoginWindow();
            }
        });
        builder.show();
    }

    /*
     * 进入程序的登录界面
     */
    private void gotoLoginWindow(){
        // new Handler().postDelayed(new Runnable() {
        //     @Override
        //     public void run() {
        Log.i(TAG, "gotoLoginWindow");
        Intent intent = new Intent(SplashActivity.this,LoginActivity.class);
        startActivity(intent);
        //结束掉当前的activity
        finish();
        //    }
        //},1000);


    }
}
