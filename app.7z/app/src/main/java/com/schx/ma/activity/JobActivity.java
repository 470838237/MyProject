package com.schx.ma.activity;

import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.os.Vibrator;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.Base64;
import com.schx.ma.GlobalData;
import com.schx.ma.Job;
import com.schx.ma.JobSubmit;
import com.schx.ma.R;
import com.schx.ma.util.MySQLiteOpenHelper;
import com.schx.ma.util.hexutil;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.entity.ByteArrayEntity;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class JobActivity extends ActionBarActivity {

    private static final String TAG = "com.schx.ma";
    private TextView tvCompany, tvCommunity, tvAccountName, tvAddress, tvAccount, tvPhone, tvReading, tvLastReadAt;
    private TextView tvSimId, tvBoardId, tvHeadId, tvMainError, tvSubError, tvErrorDetail, new_phone;
    private EditText edtContent, edtRealReading, obligate_number;
    private LinearLayout imageContainer, rowPhoto;
    private GlobalData appdata;
    private ProgressDialog pDialog;
    private Job job;
    private String address;
    private int jobIndex;//在列表中的位置
    private ArrayList<String> mPhotoURi;
    private ArrayList<View> mViewContainer;
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    private String path;
    private String FLAG;
    private String KEY1;
    private String KEY2;
    private TableRow row;
    public static String infoOnImage = "";
    Button submit;
    final static int WAIT_DEAL = 1;
    final static int VIEW_JOB = 2;
    final static int CREATE_JOB = 3;
    static int currentState = -1;
    HorizontalScrollView photoPreview;
    String KEY_NEW_PHONE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job);
        ActionBar actionBar = getActionBar();
        preferences = getSharedPreferences("SaveObjectFile", Activity.MODE_PRIVATE);
        editor = preferences.edit();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.show();
        appdata = (GlobalData) getApplication();
        String jobJson = getIntent().getStringExtra("job");
        currentState = getIntent().getIntExtra("state", -1);
        job = new Gson().fromJson(jobJson, Job.class);
        row = (TableRow) findViewById(R.id.real_reading_item);
        if (job.getMainErrorName().equals("单表故障")) {
            row.setVisibility(View.VISIBLE);
        } else {
            row.setVisibility(View.GONE);
        }
        FLAG = job.getId() + "";
        KEY_NEW_PHONE = FLAG + "newphone";
        KEY1 = FLAG + "KEY1";
        KEY2 = FLAG + "KEY2";
        MainActivity.setLocationListener(new MainActivity.LocationRefresh() {
            @Override
            public void locationRefresh(String location) {
                address = location;
            }
        });
        address = getIntent().getStringExtra("address");
        jobIndex = getIntent().getIntExtra("index", -1);
        rowPhoto = (LinearLayout) findViewById(R.id.row_photo);
        photoPreview = (HorizontalScrollView) findViewById(R.id.photoPreview);
        submit = (Button) findViewById(R.id.button_submit_job);
        tvCompany = (TextView) findViewById(R.id.textView_company);
        tvCommunity = (TextView) findViewById(R.id.textView_community);
        tvAccountName = (TextView) findViewById(R.id.textView_account_name);
        tvAddress = (TextView) findViewById(R.id.textView_address);
        tvAccount = (TextView) findViewById(R.id.textView_account);
        tvPhone = (TextView) findViewById(R.id.textView_phone);
        tvReading = (TextView) findViewById(R.id.textView_reading);
        tvLastReadAt = (TextView) findViewById(R.id.textView_last_read_at);
        tvSimId = (TextView) findViewById(R.id.textView_sim_id);
        tvBoardId = (TextView) findViewById(R.id.textView_board_id);
        tvHeadId = (TextView) findViewById(R.id.textView_head_id);
        tvMainError = (TextView) findViewById(R.id.textView_main_error);
        tvSubError = (TextView) findViewById(R.id.textView_sub_error);
        tvErrorDetail = (TextView) findViewById(R.id.textView_error_detail);
        imageContainer = (LinearLayout) findViewById(R.id.image_container);
        edtContent = (EditText) findViewById(R.id.editText_content);
        edtRealReading = (EditText) findViewById(R.id.editText_real_reading);
        obligate_number = (EditText) findViewById(R.id.obligate_number);
        new_phone = (TextView) findViewById(R.id.new_number);
        new_phone.setText(job.getNew_phone());
        savePhoneNumber();
        tvCompany.setText(job.getCompany().getName());
        tvCommunity.setText(job.getCommunity());
        tvAccountName.setText(job.getAccount_name());
        tvAddress.setText(job.getAddress());//
        tvAccount.setText(job.getAccount());//
        tvPhone.setText(job.getPhone());//
        tvReading.setText(String.valueOf(job.getReading()));
        tvLastReadAt.setText(hexutil.dateToString(job.getLast_read_at()));
        tvSimId.setText(job.getSim_id());
        tvBoardId.setText(job.getBoard_id());
        tvHeadId.setText(job.getHead_id());
        tvMainError.setText(job.getMainErrorName());
        tvSubError.setText(job.getSubErrorName());
        tvErrorDetail.setText(job.getError_detail());
        mViewContainer = new ArrayList<View>();
        mPhotoURi = (ArrayList<String>) getData();
        if (currentState == VIEW_JOB) {
            findViewById(R.id.phone_row).setVisibility(View.GONE);
            rowPhoto.setVisibility(View.GONE);
            submit.setVisibility(View.GONE);
            edtContent.setFocusable(false);
            edtContent.setText(job.getContent());
            edtRealReading.setFocusable(false);
            edtRealReading.setHint("");
            edtContent.setHint("");
            edtRealReading.setLines(1);
            edtRealReading.setGravity(Gravity.CENTER);
            edtContent.setGravity(Gravity.CENTER);
            edtRealReading.setText(job.getReal_reading() + "");
            photoPreview.setVisibility(View.INVISIBLE);
        } else if (currentState == WAIT_DEAL) {
            edtContent.requestFocus();
        }
        getImageView(mPhotoURi);
        if (currentState == WAIT_DEAL) {
            getTextData();
        }

    }

    long preTime;


    public void savePhoneNumber() {

        String saveNumber = preferences.getString(KEY_NEW_PHONE, null);
        obligate_number.setText(saveNumber);
        obligate_number.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long nowTime = System.currentTimeMillis();
                if (nowTime - preTime < 1000) {
                    obligate_number.setFocusableInTouchMode(true);
                    obligate_number.requestFocus();
                } else {
                    preTime = nowTime;
                }

            }
        });
        obligate_number.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                Log.e("hasFocus", "hasFocus");
                if (!hasFocus) {
                    obligate_number.setFocusableInTouchMode(false);
                    editor.putString(KEY_NEW_PHONE, obligate_number.getText().toString()).commit();
                }
            }
        });

    }

    public void getTextData() {
        String resultOfMaintenance = preferences.getString(KEY1, null);
        String actualData = preferences.getString(KEY2, null);
        if (resultOfMaintenance != null) {
            edtContent.setText(resultOfMaintenance);
        }
        if (actualData != null) {
            edtRealReading.setText(actualData);
        }
    }

    @Override
    protected void onPause() {
        String resultOfMaintenance = edtContent.getText().toString();
        String actualData = edtRealReading.getText().toString();
        if (currentState == WAIT_DEAL) {
            if (resultOfMaintenance != null) {
                editor.putString(KEY1, resultOfMaintenance).commit();
            }
            if (actualData != null) {
                editor.putString(KEY2, actualData).commit();
            }
        }
        editor.putString(KEY_NEW_PHONE, obligate_number.getText().toString()).commit();
        super.onPause();
    }

    public void addPhoto(View view) {
        try {
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_PICK);
            intent.setType("image/*");
            String path = getPhotoPath(0);
            //path="/storage/emulated/0/DCIM/Camera";
            File file = new File(path);
            Log.e("file", " " + file.exists());
            Log.e("file", " " + file.isDirectory());
            Uri uri = Uri.fromFile(file);
            Log.e("addPhoto", " " + uri);
            intent.setData(uri);
            startActivityForResult(intent, 2);
        } catch (Exception e) {
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(intent, 2);
        }

    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    public static String getPath(final Context context, final Uri uri) {
//        Log.e("uri--"," 1"+uri.getAuthority());
//        Log.e("uri---","2 "+DocumentsContract.getDocumentId(uri));
//        Log.e("uri---","3 "+uri.getScheme());
//        Log.e("uri---","4 "+DocumentsContract.getDocumentId(uri).split(":")[0]);
//        Log.e("uri---","5 "+DocumentsContract.getDocumentId(uri).split(":")[1]);
        final boolean isKitKat = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;

        // DocumentProvider
        if (isKitKat && DocumentsContract.isDocumentUri(context, uri)) {
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }

                // TODO handle non-primary volumes
            }
            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {

                final String id = DocumentsContract.getDocumentId(uri);
                final Uri contentUri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

                return getDataColumn(context, contentUri, null, null);
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[]{
                        split[1]
                };

                return getDataColumn(context, contentUri, selection, selectionArgs);
            }
        }
        // MediaStore (and general)
        else if ("content".equalsIgnoreCase(uri.getScheme())) {
            return getDataColumn(context, uri, null, null);
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }

        return null;
    }

    public static String getDataColumn(Context context, Uri uri, String selection,
                                       String[] selectionArgs) {

        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = {
                column
        };

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs,
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                final int column_index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(column_index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }


    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    public void deletePhoto(View view) {


        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                }).setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ArrayList<View> temp = new ArrayList<View>();
                        for (int i = 0; i < mViewContainer.size(); i++) {
                            View v = mViewContainer.get(i);
                            CheckedTextView ctv = (CheckedTextView) v.getTag();
                            if (ctv.isChecked()) {
                                mPhotoURi.set(i, "0");
                                imageContainer.removeView(v);
                                temp.add(v);
                            }
                        }
                        mPhotoURi.remove("0");
                        saveData(mPhotoURi);
                        mViewContainer.removeAll(temp);
                    }
                }).setTitle("是否删除");

        AlertDialog dialog = builder.create();

        dialog.show();
    }

    public void takePhoto(View view) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        path = getPhotoPath(1);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(path)));
        startActivityForResult(intent, 1);
    }


    Intent intentService;

    public void startService(String path) {
        intentService = new Intent(this, CompoundService.class);
        intentService.putExtra("path", path);
        startService(intentService);
    }


    //获取相机返回图片添加到容器
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd  HH:mm:ss");
            String date = format.format(new Date());
            String number = job.getPhone();
            String new_number = obligate_number.getText().toString();
            if (new_number.length() > 8)
                number = new_number;
            infoOnImage = "结算号:" + job.getAccount() + ",地址:" + job.getAddress() + ",电话:" + number + ",日期:" + date;
            startService(path);
            ArrayList<String> temp = new ArrayList<String>();
            temp.add(path);
            mPhotoURi.add(path);
            getImageView(temp);
            saveData(mPhotoURi);
        }
        if (requestCode == 2 && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            Log.e("uri", " " + uri);
            String path = uri.toString();
            Log.e("String", "" + path);
            if (path.startsWith("content://com.android")) {
                path = getPath(this, uri);
            } else {
                path = getRealFilePath(this, uri);
            }
            Log.e("onActivityResult", " " + path);
            ArrayList<String> list = new ArrayList<String>();
            mPhotoURi.add(path);
            saveData(mPhotoURi);
            list.add(path);
            getImageView(list);
        }
    }

    public static String getRealFilePath(final Context context, final Uri uri) {
        if (null == uri) return null;
        final String scheme = uri.getScheme();
        String data = null;
        if (scheme == null)
            data = uri.getPath();
        else if (ContentResolver.SCHEME_FILE.equals(scheme)) {
            data = uri.getPath();
        } else if (ContentResolver.SCHEME_CONTENT.equals(scheme)) {
            Cursor cursor = context.getContentResolver().query(uri, new String[]{MediaStore.Images.ImageColumns.DATA}, null, null, null);
            if (null != cursor) {
                if (cursor.moveToFirst()) {
                    int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
                    if (index > -1) {
                        data = cursor.getString(index);
                    }
                }
                cursor.close();
            }
        }
        return data;
    }

    public void getImageView(ArrayList<String> list) {
        for (int i = 0; i < list.size(); i++) {
            String path = list.get(i);
            File file = new File(path);
            if (!file.exists()) {
                mPhotoURi.remove(path);
                saveData(mPhotoURi);
                list.remove(path);
                i--;
                continue;
            }
            View view = getLayoutInflater().inflate(R.layout.job_scrollview_item, null);
            LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(-2, -2);
            llp.rightMargin = 40;
            view.setLayoutParams(llp);
            ImageView imgJob = (ImageView) view.findViewById(R.id.img_job);
            final CheckedTextView choiceJob = (CheckedTextView) view.findViewById(R.id.choice_job);
            view.setTag(choiceJob);
            imageContainer.addView(view);
            mViewContainer.add(view);
            BitmapFactory.Options ops = new BitmapFactory.Options();
            ops.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, ops);
            ops.inSampleSize = computeSampleSize(ops, -1, 200 * 200);
            ops.inJustDecodeBounds = false;
            Bitmap bitmap = BitmapFactory.decodeFile(path, ops);
            Log.e("bitmap", "" + bitmap);
//            if (bitmap != null)
//                bitmap = compoundImage(bitmap);
            imgJob.setImageBitmap(bitmap);
            choiceJob.setTag(mPhotoURi.indexOf(path));
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(JobActivity.this, PhotoBrowserActivity.class);
                    intent.putStringArrayListExtra("mPhotoURi", mPhotoURi);
                    CheckedTextView ctv = (CheckedTextView) v.getTag();

                    intent.putExtra("index", (Integer) ctv.getTag());
                    startActivity(intent);
                }
            });
            if (currentState == WAIT_DEAL) {
                view.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View view) {
                        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                        long[] pattern = {100, 100};
                        vibrator.vibrate(pattern, -1);
                        CheckedTextView ctv = (CheckedTextView) view.getTag();
                        if (!ctv.isChecked()) {
                            ctv.setChecked(true);
                            ctv.setVisibility(View.VISIBLE);

                        } else {
                            ctv.setChecked(false);
                            ctv.setVisibility(View.INVISIBLE);
                        }
                        return true;
                    }
                });
            }

        }
    }

    public void saveData(Object object) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(object);
            String objStr = Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);
            editor.putString(FLAG, objStr).commit();
            oos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Object getData() {
        Object obj = null;
        String objStr = preferences.getString(FLAG, null);
        if (objStr == null) {
            obj = new ArrayList<String>();
        } else {
            byte[] strByte = Base64.decode(objStr.getBytes(), Base64.DEFAULT);
            ByteArrayInputStream bais = new ByteArrayInputStream(strByte);
            try {
                ObjectInputStream ois = new ObjectInputStream(bais);
                obj = ois.readObject();
                ois.close();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return obj;
    }

    public static int computeSampleSize(BitmapFactory.Options options,
                                        int minSideLength, int maxNumOfPixels) {

        int initialSize = computeInitialSampleSize(options, minSideLength,
                maxNumOfPixels);

        int roundedSize;
        if (initialSize <= 8) {
            roundedSize = 1;
            while (roundedSize < initialSize) {
                roundedSize <<= 1;
            }
        } else {
            roundedSize = (initialSize + 7) / 8 * 8;
        }
        return roundedSize;
    }

    private static int computeInitialSampleSize(BitmapFactory.Options options,
                                                int minSideLength, int maxNumOfPixels) {
        double w = options.outWidth;
        double h = options.outHeight;
        int lowerBound = (maxNumOfPixels == -1) ? 1 :
                (int) Math.ceil(Math.sqrt(w * h / maxNumOfPixels));
        int upperBound = (minSideLength == -1) ? 128 :
                (int) Math.min(Math.floor(w / minSideLength),
                        Math.floor(h / minSideLength));

        if (upperBound < lowerBound) {
            return lowerBound;
        }
        if ((maxNumOfPixels == -1) &&
                (minSideLength == -1)) {
            return 1;
        } else if (minSideLength == -1) {
            return lowerBound;
        } else {
            return upperBound;
        }
    }

    public String getPhotoPath(int flag) {
        String path = null;
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            path = Environment.getExternalStorageDirectory().getPath() + File.separator  + "工程维护图库";
        }
        File file = new File(path);
        File file1=new File(Environment.getExternalStorageDirectory().getPath() + File.separator  + "恒芯周报图库");
        if (file1.exists()) {
            file1.renameTo(file);
        }else if(!file1.exists()&&!file.exists()){
            file.mkdir();
        }
        path = path + File.separator + job.getCommunity();
        file = new File(path);
        if (!file.mkdir()) {
            file.mkdir();
        }
        if (flag == 0) {
            return path;
        }
        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
        path = path + File.separator + format.format(date) + ".jpg";
        return path;
    }

    public Bitmap storePhotos2sdCard(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        int scale = 50 / (baos.toByteArray().length / 1024);
        baos.reset();
        bitmap.compress(Bitmap.CompressFormat.JPEG, scale, baos);
        ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
        Bitmap bitmap1 = BitmapFactory.decodeStream(bais, null, null);
        return bitmap1;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                //没有提交，直接返回
                setResult(RESULT_CANCELED, null);
                finish();
                return true;
        }
        return true;
    }

    public void onCallPhone(View view) {
        String strMobile = tvPhone.getText().toString();
        if (strMobile.length() <= 6)
            return;
        //此处应该对电话号码进行验证。。
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + strMobile));
        JobActivity.this.startActivity(intent);
    }

    public void onPhotoClicked(View view) {
        //finish();
    }

    public void onDelPhotoClicked(View view) {

    }

    public String bitmap2String(String path) {
        BitmapFactory.Options ops = new BitmapFactory.Options();
        Bitmap bitmap;
        ops.inJustDecodeBounds = false;
        ops.inSampleSize = 1;
        bitmap = BitmapFactory.decodeFile(path, ops);
        Matrix matrix = new Matrix();
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        float scaleX = (float) (800.0 / w);
        float scaleY = (float) (600.0 / h);
        matrix.setScale(scaleX, scaleY);
        bitmap = Bitmap.createBitmap(bitmap, 0, 0, w, h, matrix, true);
        // bitmap = compoundImage(bitmap);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, baos);
        byte[] bitmapByteArray = Base64.encode(baos.toByteArray(), Base64.DEFAULT);
        String byteString = new String(bitmapByteArray);
        return byteString;
    }

    public static Bitmap compoundImage(Bitmap bitmap) {
        Bitmap canvasMap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), bitmap.getConfig());
        Canvas canvas = new Canvas(canvasMap);
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        float height = canvas.getHeight();
        float width = canvas.getWidth();
        canvas.drawBitmap(bitmap, new Matrix(), paint);
        bitmap.recycle();
        paint.setTextAlign(Paint.Align.CENTER);
        float fontSize;
        if (height > width)
            fontSize = height / 25;
        else {
            fontSize = width / 25;
        }

        paint.setTextSize(fontSize);
        float halfOfHeight = height / 2;
        String[] arrStr = infoOnImage.split(",");
        paint.setColor(Color.RED);
        float strWidth = new Paint().measureText(arrStr[1]);
        int row = (int) (strWidth / (2.0 / 3 * width));
        if (width > height) {
            canvas.save();
            canvas.rotate(90, width / 2, height / 2);
        }
        float initY = (float) (halfOfHeight - ((arrStr.length - 1) * 2 + row * 2) / 2.0) + 6* fontSize;
        for (int i = 0; i < arrStr.length; i++) {
            float pointY;
            if (i < 2) {
                pointY = initY + fontSize * 1.5f * i;
            } else {
                pointY = initY + i * 1.5f * fontSize + row * fontSize;
            }

            canvas.drawText(arrStr[i], width / 2, pointY, paint);
        }
        if (width > height) {
            canvas.restore();
        }

        return canvasMap;
    }

    public void onSubmitClicked(View view) {
        String content, real_reading;
        content = edtContent.getText().toString().trim();
        real_reading = edtRealReading.getText().toString().trim();
        if (job.getMainErrorName().equals("单表故障")) {

            if (content.isEmpty() || real_reading.isEmpty()) {
                Toast.makeText(this, "维修结果或实际读数不能为空，请修改！", Toast.LENGTH_SHORT).show();
                return;
            }
        } else {
            if (content.isEmpty()) {
                Toast.makeText(this, "维修结果不能为空，请修改！", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        pDialog = ProgressDialog.show(this, "请稍等", "正在保存维修单信息...");
        String HttpUrl = appdata.getBaseUrl() + "/appv1/update_job?";
        JobSubmit jobSubmit = new JobSubmit();
        jobSubmit.id = job.getId();
        jobSubmit.content = content;
        jobSubmit.real_reading = real_reading;
        jobSubmit.gps_address = address;
        jobSubmit.user_id = appdata.getLoginId();
        String phone = obligate_number.getText().toString();
        if (phone.length() >= 8)
            jobSubmit.new_phone = phone;
        editor.putString(KEY_NEW_PHONE, "").commit();
        ArrayList<String> temp = new ArrayList<String>();
        for (int i = 0; i < mPhotoURi.size(); i++) {
            temp.add(bitmap2String(mPhotoURi.get(i)));
        }
        jobSubmit.photos = temp;
        Gson json = new Gson();
        String jsonStr = json.toJson(jobSubmit);
        int len = jsonStr.getBytes().length / 1024;
        HttpEntity entity = new ByteArrayEntity(jsonStr.getBytes());
        new AsyncHttpClient().post(this, HttpUrl, entity, "application/json", new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int i, Header[] headers, byte[] bytes) {
                doServerPostResult(new String(bytes));
                MySQLiteOpenHelper mySQLiteOpenHelper = GlobalData.getDBhelper(JobActivity.this);
                mySQLiteOpenHelper.deleteData(new String[]{job.getId() + "", currentState + ""});
                pDialog.dismiss();
            }

            @Override
            public void onFailure(int i, Header[] headers, byte[] bytes, Throwable throwable) {
                if (bytes != null) {
                    Toast.makeText(JobActivity.this, "保存维修单失败," + new String(bytes),
                            Toast.LENGTH_LONG).show();

                } else {
                    Toast.makeText(JobActivity.this, "保存维修单失败," + throwable.getMessage(),
                            Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void doServerPostResult(String s) {
        Log.d(TAG, "doServerPostResult():" + s);
        if (s.equalsIgnoreCase("success")) {
            Toast.makeText(JobActivity.this, "保存维修单成功。",
                    Toast.LENGTH_LONG).show();
            Intent intent = new Intent();
            Bundle bundle = new Bundle();
            bundle.putInt("index", jobIndex);
            intent.putExtras(bundle);
            //设置回调的方法
            setResult(RESULT_OK, intent);
            finish();
        } else
            Toast.makeText(JobActivity.this, "保存维修单失败，请联系管理员。",
                    Toast.LENGTH_LONG).show();
    }

    @Override
    public android.support.v4.app.FragmentManager getSupportFragmentManager() {
        return null;
    }
}
