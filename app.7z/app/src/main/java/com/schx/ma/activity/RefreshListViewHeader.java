package com.schx.ma.activity;

import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.schx.ma.Job;
import com.schx.ma.R;
import com.schx.ma.userdefineview.RefreshListView;
import com.schx.ma.util.JobPreviewAdapter;

import java.util.ArrayList;

/**
 * Created by yuan on 2016/5/30.
 */
public class RefreshListViewHeader implements RefreshListView.CallBackRefresh {
    private LinearLayout mContainer;
    private ImageView mRefresh;
    private boolean flag = true;
    public RelativeLayout mRefreshContainer;
    int mHeightOfRefreshContainer = 0;
    Animation animation;
    RefreshListView listView;
    MainActivity activity;
    JobPreviewAdapter adapter;
    ArrayList<Job> datas;

    public TextView getDisplayState() {
        return displayState;
    }

    public void setDisplayState(TextView displayState) {
        this.displayState = displayState;
    }

    TextView displayState;

    public RefreshListViewHeader(final MainActivity activity, RefreshListView listView, JobPreviewAdapter adapter, ArrayList<Job> datas) {
        this.activity = activity;
        this.listView = listView;
        this.adapter = adapter;
        this.datas = datas;
        listView.setOnRefreshListener(this);

        mContainer = (LinearLayout) activity.getLayoutInflater().inflate(R.layout.main_list_header, null);
        mRefreshContainer = (RelativeLayout) mContainer.findViewById(R.id.refresh_container);
        mRefresh = (ImageView) mContainer.findViewById(R.id.refresh_view);
        listView.addHeaderView(mContainer);
        animation = new RotateAnimation(0f, 360.0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        animation.setFillAfter(true);
        animation.setRepeatCount(Animation.INFINITE);
        animation.setDuration(1000);
        listView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (flag) {
                    return false;
                } else {
                    return true;
                }

            }
        });
    }

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 0) {

                activity.onQueryClick(mRefresh);
            }
        }
    };

    @Override
    public void refresh(int moveY,int state) {
        if (flag) {
            LinearLayout.LayoutParams fllp = new LinearLayout.LayoutParams(-1, -2);
            fllp.height = mHeightOfRefreshContainer + moveY;
            if (moveY > 0 && moveY < 200) {
                mRefreshContainer.setVisibility(View.VISIBLE);
                mRefreshContainer.setLayoutParams(fllp);
            }
            if (moveY == -1&&state==1) {
                flag = false;
                mRefresh.startAnimation(animation);
                new Thread() {
                    @Override
                    public void run() {

                        if (!flag) {
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            handler.sendEmptyMessage(0);
                        }
                    }
                }.start();
            }
        }
    }

    public void refreshSuccess(View view) {
        if (mRefresh != null) {
            flag = true;
            if (datas.size()==0){
                displayState.setAlpha(1);
                displayState.setText("暂无维修单");
            }else {
                displayState.setAlpha(0);
            }

            mRefresh.clearAnimation();
            mRefreshContainer.setVisibility(View.GONE);
            String text;
            if (view==null)
                text="加载成功";
            else
                text="刷新成功";
            Toast.makeText(activity, text, Toast.LENGTH_SHORT).show();
        }
    }

    public void refreshFail(String text) {
        if (mRefresh != null) {
            flag = true;
            datas.clear();
            adapter.notifyDataSetChanged();
            displayState.setAlpha(1);
            displayState.setText(text+"\n\n获取数据失败,下拉页面刷新");
            mRefresh.clearAnimation();
            mRefreshContainer.setVisibility(View.GONE);
            Toast.makeText(activity, text, Toast.LENGTH_SHORT).show();
        }
    }

}
