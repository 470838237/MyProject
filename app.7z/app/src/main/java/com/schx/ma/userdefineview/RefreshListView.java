package com.schx.ma.userdefineview;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AbsListView;
import android.widget.ListView;

import com.schx.ma.activity.RefreshListViewHeader;

/**
 * Created by Administrator on 2016/5/11 0011.
 */
public class RefreshListView extends ListView implements AbsListView.OnScrollListener {
    int preY;
    int moveY;
    static int currentPage = 1;
    CallBackRefresh refresh;
    static int currentItem = 0;
    CallBack callBack;
    int totalCounter = 10;
    boolean flag;

    public RefreshListView(Context context) {
        super(context);
        this.setOnScrollListener(this);
    }

    public RefreshListView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.setOnScrollListener(this);

    }

    @Override
    protected void onScrollChanged(int l, int t, int oldl, int oldt) {
        super.onScrollChanged(l, t, oldl, oldt);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int currentY = (int) event.getY();
        switch (event.getAction()) {

            case MotionEvent.ACTION_DOWN:
                preY = currentY;
                break;
            case MotionEvent.ACTION_MOVE:

                    moveY = (currentY - preY) / 4;
                    refresh.refresh(moveY, 2);
                    break;


            case MotionEvent.ACTION_UP:
                Log.e("moveY",moveY+"");
                if (currentItem == 0 && moveY > 150) {
                    refresh.refresh(-1, 1);
                } else {
                    ((RefreshListViewHeader) refresh).mRefreshContainer.setVisibility(View.GONE);
                }
                if (flag && moveY < -100)
                    callBack.onPageChangeListenter();
                break;
            default:
                break;
        }
        return super.onTouchEvent(event);
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        currentItem = firstVisibleItem;
        if (firstVisibleItem + visibleItemCount == totalItemCount) {
            if (this.getAdapter() != null && callBack != null) {
                flag = true;
                Log.e("onScroll", firstVisibleItem + visibleItemCount + "   " + totalItemCount);
            } else {
                flag = false;
            }

        }else {
            flag = false;
        }
    }

    public interface CallBackRefresh {
        void refresh(int moveY, int state);
    }

    public void setOnRefreshListener(CallBackRefresh refresh) {
        this.refresh = refresh;

    }

    public interface CallBack {
        int onPageChangeListenter();
    }

    public void setonPageChangeListenter(CallBack back) {
        this.callBack = back;
    }
}
