package com.schx.ma.util;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.support.v4.view.PagerAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.schx.ma.R;
import com.schx.ma.activity.JobActivity;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by yuan on 2016/5/16.
 */
public class MyPagerAdapter extends PagerAdapter {
    ArrayList<String> items;
    Activity activity;
    LayoutInflater inflater;
    HashMap<Integer, View> mviews;
    int index;
    Bitmap bitmap;

    public MyPagerAdapter(int index, ArrayList<String> items, Activity activity) {
        this.items = items;
        this.activity = activity;
        inflater = activity.getLayoutInflater();
        mviews = new HashMap<Integer, View>();
        this.index = index;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return object == view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View view;
        if (!mviews.containsKey(position)) {
            view = inflater.inflate(R.layout.browse_viewpager_item, null);
            mviews.put(position, view);
            bitmap = getBitmap(position);
            ImageView iv = (ImageView) view.findViewById(R.id.photo_browse_view);
            int view_height=activity.getWindowManager().getDefaultDisplay().getWidth()*bitmap.getHeight()/bitmap.getWidth();
            int height=activity.getWindowManager().getDefaultDisplay().getHeight();
            int margin_top=(height-view_height)/2;
            RelativeLayout.LayoutParams p=new RelativeLayout.LayoutParams(-1,view_height);
            p.topMargin=margin_top;
            iv.setLayoutParams(p);
            iv.setImageBitmap(bitmap);
            view.setTag(iv);
            TextView tv = (TextView) view.findViewById(R.id.counter_view);
            Log.e("position", "" + position);
            String str = position + 1 + "/" + items.size();
            tv.setText(str);
        }
        view = mviews.get(position);
        container.removeView(view);
        container.addView(view);
        return view;
    }

    public Bitmap getBitmap(int position) {
        BitmapFactory.Options ops = new BitmapFactory.Options();
        ops.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(items.get(position), ops);
        ops.inSampleSize = JobActivity.computeSampleSize(ops, -1, 1800 * 1400);
        ops.inJustDecodeBounds = false;
        Bitmap bitmap = BitmapFactory.decodeFile(items.get(position), ops);
        if (bitmap!=null&&bitmap.getWidth()>bitmap.getHeight())
            bitmap=adjustPhotoRotation(bitmap,-90);
        return bitmap;
    }

   public Bitmap adjustPhotoRotation(Bitmap bm, final int orientationDegree) {
        Matrix m = new Matrix();
        m.setRotate(orientationDegree, (float) bm.getWidth() / 2, (float) bm.getHeight() / 2);

        try {
            Bitmap bm1 = Bitmap.createBitmap(bm, 0, 0, bm.getWidth(), bm.getHeight(), m, true);
            bm.recycle();
            return bm1;
        } catch (OutOfMemoryError ex) {
        }
        return null;
    }
//    public void sort(ArrayList<View> list) {
//        for (int i = 0; i < list.size(); i++) {
//            Integer position = (Integer) list.get(i).getTag();
//            View temp = list.get(i);
//            list.set(i, list.get(position));
//            list.set(position, temp);
//        }
//    }
}
