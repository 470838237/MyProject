package com.schx.ma.util;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.schx.ma.Job;

import java.util.ArrayList;

/**
 * Created by yuan on 2016/5/23.
 */
public class MySQLiteOpenHelper extends SQLiteOpenHelper {
    SQLiteDatabase db;
    String createTable = "create table jobinfo(id integer primary key autoincrement,jobid integer," +
            "company text,address text,mistake text,date text,object text,state integer,content text,isExist Integer,userid text) ";
    public MySQLiteOpenHelper(Context context, String name,
                              int version) {
        super(context, name, null, version);
        getDB();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(createTable);
    }

    public void getDB() {
        if (db == null) {
            db = this.getWritableDatabase();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE jobinfo");
        db.execSQL(createTable);
    }

    public void insertData(String insert, String[] data) {
        db.execSQL(insert, data);
    }

    public void selectData(String select, String[] data, ArrayList<String> temp) {
        Cursor cursor = db.rawQuery(select, data);
        temp.clear();
        while (cursor.moveToNext()) {
            String info = cursor.getString(0);
            if (!temp.contains(info))
                temp.add(info);
        }
    }

    public void selectJob(String select, String[] data, ArrayList<Integer> temp) {
        Cursor cursor = db.rawQuery(select, data);
        temp.clear();
        while (cursor.moveToNext()) {
            String id = cursor.getString(cursor.getColumnIndex("jobid"));
            int jobid = Integer.parseInt(id);
            if (!temp.contains(jobid))
                temp.add(jobid);
        }
    }

    public boolean isDataExist(String[] data) {
        String select = "select count(1) from jobinfo where jobid=? and state=? and isExist=1 and userid=?";
        Cursor cursor = db.rawQuery(select, data);
        cursor.moveToFirst();
        String result = cursor.getString(0);
        if (Integer.parseInt(result) > 0)
            return true;
        else
            return false;
    }
    public void deleteData(String[] data) {
        String delete = "update jobinfo set  isExist=0 where jobid=? and state=? and userid=?";
        db.execSQL(delete, data);
    }
}
