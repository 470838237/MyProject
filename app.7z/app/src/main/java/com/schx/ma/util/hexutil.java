package com.schx.ma.util;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;

/*
 /*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * @author ma
 */
public class hexutil {

    public static String dateToString(Date time) {
        SimpleDateFormat formatter;
        formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String ctime = formatter.format(time);
        return ctime;
    }

    /*字符串前面加0*/
    public static String fillZeroStr(String oldstr, int len) {
        String newstr;
        newstr = "00000000" + oldstr;
        int all = newstr.length();
        newstr = newstr.substring(all - len, all);
        return newstr;
    }

    /*字符串后面加0*/
    public static String addZeroStr(String oldstr, int len) {
        String newstr;
        newstr = oldstr + "000000000000000000";
        newstr = newstr.substring(0, len);
        return newstr;
    }

    public static String readFile(String fileName) {
        String output = "";

        File file = new File(fileName);

        if (file.exists()) {
            if (file.isFile()) {
                try {
                    BufferedReader input = new BufferedReader(new FileReader(file));
                    StringBuilder buffer = new StringBuilder();
                    String text;

                    while ((text = input.readLine()) != null) {
                        buffer.append(text);
                    }

                    output = buffer.toString();
                } catch (IOException ioException) {
                    System.err.println(fileName + " File Error!");

                }
            } else if (file.isDirectory()) {
                String[] dir = file.list();
                output += "Directory contents:/n";

                for (int i = 0; i < dir.length; i++) {
                    output += dir[i] + "/n";
                }
            }
        } else {
            System.err.println(fileName + " Does not exist!");
        }
        return output;
    }

    //return jar file path

    public static String getJarPath() {
        String path = hexutil.class.getProtectionDomain().getCodeSource().getLocation().getPath();
        try {
            //去掉目录中的空格和中文
            path = URLDecoder.decode(path, "gbk");
        } catch (UnsupportedEncodingException ex) {
            java.util.logging.Logger.getLogger(hexutil.class.getName()).log(Level.SEVERE, null, ex);
        }
        File file = new File(path.toString());
        //包外
        String filename = file.getParent();
        return filename;
    }

    public static String stringMD5(String input) {
        try {
            // 拿到一个MD5转换器（如果想要SHA1参数换成”SHA1”）
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            // 输入的字符串转换成字节数组
            byte[] inputByteArray = input.getBytes();
            // inputByteArray是输入字符串转换得到的字节数组
            messageDigest.update(inputByteArray);
            // 转换并返回结果，也是字节数组，包含16个元素
            byte[] resultByteArray = messageDigest.digest();
            // 字符数组转换成字符串返回
            return byteArrayToHex(resultByteArray);
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }

    public static String byteArrayToHex(byte[] byteArray) {
        // 首先初始化一个字符数组，用来存放每个16进制字符
        char[] hexDigits = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
        // new一个字符数组，这个就是用来组成结果字符串的（解释一下：一个byte是八位二进制，也就是2位十六进制字符（2的8次方等于16的2次方））
        char[] resultCharArray = new char[byteArray.length * 2];
        // 遍历字节数组，通过位运算（位运算效率高），转换成字符放到字符数组中去
        int index = 0;
        for (byte b : byteArray) {
            resultCharArray[index++] = hexDigits[b >>> 4 & 0xf];
            resultCharArray[index++] = hexDigits[b & 0xf];
        }
        // 字符数组组合成字符串返回
        return new String(resultCharArray);

    }

    //截取字符串中<span id="Label1">1,3</span>中间的值
    public static String splitSpanStr(String spanstr) {
        int index_begin = spanstr.indexOf("span");
        int index_end = spanstr.lastIndexOf("span");
        if (index_begin < 1 || index_end < 1) {
            return "";
        }
        String content = spanstr.substring(index_begin + 17, index_end - 2);
        return content;
    }

}
