package com.schx.ma;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by ma on 2016/3/24.
 */
public class Job implements Serializable {
    private int id;
    private String sn;
    private String meter_type;
    private String account;
    private String meter_code;
    private String account_name;
    private String address;
    private String phone;
    private double reading;
    private Date last_read_at;
    private String factory_name;
    private String community;
    private String sim_id;
    private String board_id;
    private String head_id;
    private String gas_direction;
    private String creator;
    private Company company;
    private Main_Error main_error;
    private Sub_Error sub_error;
    private String error_detail;
    private int state;
    private Date created_at;
    private String content;
    public String real_reading;
    private String new_phone;

    public String getNew_phone() {
        return new_phone;
    }

    public void setNew_phone(String new_phone) {
        this.new_phone = new_phone;
    }

    public String getContent() {
        return content;
    }

    public void setConetent(String content) {
        this.content = content;
    }

    public String getReal_reading() {
        if(real_reading==null)
            real_reading="-1";
        return real_reading;
    }

    public void setReal_reading(String Real_reading) {
        this.real_reading = Real_reading;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getMeter_type() {
        return meter_type;
    }

    public void setMeter_type(String meter_type) {
        this.meter_type = meter_type;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getMeter_code() {
        return meter_code;
    }

    public void setMeter_code(String meter_code) {
        this.meter_code = meter_code;
    }

    public String getAccount_name() {
        return account_name;
    }

    public void setAccount_name(String account_name) {
        this.account_name = account_name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public double getReading() {
        return reading;
    }

    public void setReading(double reading) {
        this.reading = reading;
    }

    public Date getLast_read_at() {
        return last_read_at;
    }

    public void setLast_read_at(Date last_read_at) {
        this.last_read_at = last_read_at;
    }

    public String getFactory_name() {
        return factory_name;
    }

    public void setFactory_name(String factory_name) {
        this.factory_name = factory_name;
    }

    public String getCommunity() {
        return community;
    }

    public void setCommunity(String community) {
        this.community = community;
    }

    public String getSim_id() {
        return sim_id;
    }

    public void setSim_id(String sim_id) {
        this.sim_id = sim_id;
    }

    public String getBoard_id() {
        return board_id;
    }

    public void setBoard_id(String board_id) {
        this.board_id = board_id;
    }

    public String getHead_id() {
        return head_id;
    }

    public void setHead_id(String head_id) {
        this.head_id = head_id;
    }

    public String getGas_direction() {
        return gas_direction;
    }

    public void setGas_direction(String gas_direction) {
        this.gas_direction = gas_direction;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public Main_Error getMain_error() {
        return main_error;
    }

    public void setMain_error(Main_Error main_error) {
        this.main_error = main_error;
    }

    public Sub_Error getSub_error() {
        return sub_error;
    }

    public void setSub_error(Sub_Error sub_error) {
        this.sub_error = sub_error;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public Date getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Date created_at) {
        this.created_at = created_at;
    }

    public class Company {
        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public class Main_Error {
        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public String getMainErrorName() {
        if (main_error != null) {
            return main_error.getName();
        } else {
            return "";
        }
    }

    public class Sub_Error {
        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public String getSubErrorName() {
        if (sub_error != null) {
            return sub_error.getName();
        } else {
            return "";
        }
    }

    public String getError_detail() {
        return error_detail;
    }

    public void setError_detail(String error_detail) {
        this.error_detail = error_detail;
    }
}
