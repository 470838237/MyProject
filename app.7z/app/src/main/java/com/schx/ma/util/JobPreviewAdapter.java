package com.schx.ma.util;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.schx.ma.Job;
import com.schx.ma.R;
import com.schx.ma.userdefineview.RefreshListView;

import java.util.ArrayList;

/**
 * Created by yuan on 2016/5/24.
 */
public class JobPreviewAdapter extends BaseAdapter {
    ArrayList<Job> data;
     static int currentPage=1;
    int perPageCount=10;
    Activity activity;
    LayoutInflater inflate;
    ArrayList<Job> temp;
    public JobPreviewAdapter(ArrayList<Job> data, Activity activity){
        this.data=data;
        this.activity=activity;
        inflate=activity.getLayoutInflater();
        temp=new ArrayList<Job>();


    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    //这个方法才是重点，我们要为它编写一个ViewHolder
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            convertView = inflate.inflate(R.layout.listview_item_job, parent, false); //加载布局
            holder = new ViewHolder();

            holder.companyTv = (TextView) convertView.findViewById(R.id.textView_company);
            holder.communityTv = (TextView) convertView.findViewById(R.id.textView_community);
            // holder.accountNameTv = (TextView) convertView.findViewById(R.id.textView_account_name);
            //  holder.phoneTv = (TextView) convertView.findViewById(R.id.textView_phone);
            holder.addressTv = (TextView) convertView.findViewById(R.id.textView_address);
            holder.mainErrorTv = (TextView) convertView.findViewById(R.id.textView_main_error);
            //  holder.stateTv = (TextView) convertView.findViewById(R.id.textView_state);
            holder.createdAtTv = (TextView) convertView.findViewById(R.id.textView_created_at);
            convertView.setTag(holder);
        } else {   //else里面说明，convertView已经被复用了，说明convertView中已经设置过tag了，即holder
            holder = (ViewHolder) convertView.getTag();
        }
        Job job = data.get(position);
        holder.companyTv.setText(job.getCompany().getName());
        holder.communityTv.setText(job.getCommunity());
        //  holder.accountNameTv.setText(job.getAccount_name());
        //  holder.phoneTv.setText(job.getPhone());
        holder.addressTv.setText(job.getAddress());
        holder.mainErrorTv.setText(job.getMain_error().getName());
        //  holder.stateTv.setText(appdata.convertStateCode(job.getState()));
        holder.createdAtTv.setText(hexutil.dateToString(job.getCreated_at()));
        // Log.d("com.schx.ma",hexutil.dateToString(job.getCreated_at()));
        return convertView;
    }

    //这个ViewHolder只能服务于当前这个特定的adapter，因为ViewHolder里会指定item的控件，不同的ListView，item可能不同，所以ViewHolder写成一个私有的类
    private class ViewHolder {
        TextView companyTv;
        TextView communityTv;
        // TextView accountNameTv;
        TextView addressTv;
        // TextView phoneTv;
        TextView mainErrorTv;
        // TextView stateTv;
        TextView createdAtTv;
    }
}
